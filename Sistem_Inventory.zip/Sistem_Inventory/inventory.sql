-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 06, 2019 at 03:53 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id_barang` varchar(5) NOT NULL,
  `nama_barang` varchar(20) NOT NULL,
  `id_jenis_barang` varchar(5) DEFAULT NULL,
  `stock` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_barang`, `nama_barang`, `id_jenis_barang`, `stock`) VALUES
('B0001', 'Kertas Folio', 'JB001', 105),
('B0002', 'Kertas A4', 'JB001', 50);

-- --------------------------------------------------------

--
-- Table structure for table `brg_keluar`
--

CREATE TABLE `brg_keluar` (
  `id_brg_keluar` varchar(5) NOT NULL,
  `id_pengajuan` varchar(5) DEFAULT NULL,
  `id_barang` varchar(5) DEFAULT NULL,
  `jml_brg` int(3) NOT NULL,
  `satuan` varchar(10) NOT NULL,
  `tgl_pengambilan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brg_keluar`
--

INSERT INTO `brg_keluar` (`id_brg_keluar`, `id_pengajuan`, `id_barang`, `jml_brg`, `satuan`, `tgl_pengambilan`) VALUES
('BK001', 'P0001', 'B0001', 20, '', '2019-09-04'),
('BK002', 'P0001', 'B0001', 10, '', '2019-09-05');

--
-- Triggers `brg_keluar`
--
DELIMITER $$
CREATE TRIGGER `kurangi_stock` AFTER INSERT ON `brg_keluar` FOR EACH ROW BEGIN
UPDATE barang set stock = stock - NEW.jml_brg 
WHERE id_barang = NEW.id_barang;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `brg_masuk`
--

CREATE TABLE `brg_masuk` (
  `id_brg_masuk` varchar(5) NOT NULL,
  `id_supplier` varchar(5) DEFAULT NULL,
  `id_barang` varchar(5) DEFAULT NULL,
  `jml_brg` int(3) NOT NULL,
  `satuan` varchar(10) NOT NULL,
  `tgl_masuk` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brg_masuk`
--

INSERT INTO `brg_masuk` (`id_brg_masuk`, `id_supplier`, `id_barang`, `jml_brg`, `satuan`, `tgl_masuk`) VALUES
('BM001', 'SP001', 'B0001', 12, '', '2019-09-02'),
('BM002', 'SP001', 'B0002', 25, '', '2019-09-03'),
('BM003', 'SP003', 'B0001', 12, '', '2019-09-03'),
('BM004', 'SP001', 'B0001', 4, '', '2019-09-05');

--
-- Triggers `brg_masuk`
--
DELIMITER $$
CREATE TRIGGER `tambah_stock` AFTER INSERT ON `brg_masuk` FOR EACH ROW BEGIN
UPDATE barang set stock = stock + NEW.jml_brg 
WHERE id_barang = NEW.id_barang;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `jenis_barang`
--

CREATE TABLE `jenis_barang` (
  `id_jenis_barang` varchar(5) NOT NULL,
  `nama_jenis_barang` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jenis_barang`
--

INSERT INTO `jenis_barang` (`id_jenis_barang`, `nama_jenis_barang`) VALUES
('JB001', 'Kertas'),
('JB002', 'Pulpen'),
('JB003', 'Spidol'),
('JB004', 'Tinta'),
('JB005', 'Bag Document'),
('JB006', 'Amplop'),
('JB007', 'Battery'),
('JB008', 'Box File'),
('JB009', 'Clip');

-- --------------------------------------------------------

--
-- Table structure for table `pengajuan`
--

CREATE TABLE `pengajuan` (
  `id_pengajuan` varchar(5) NOT NULL,
  `id_user` varchar(5) DEFAULT NULL,
  `nama_barang` varchar(20) NOT NULL,
  `jml_barang` int(3) NOT NULL,
  `satuan` varchar(10) NOT NULL,
  `tgl_pengajuan` text NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengajuan`
--

INSERT INTO `pengajuan` (`id_pengajuan`, `id_user`, `nama_barang`, `jml_barang`, `satuan`, `tgl_pengajuan`, `status`) VALUES
('P0001', 'KP006', 'Kertas A4', 20, '', '2019-09-04', 'Disetujui'),
('P0002', 'KP007', 'Kertas Folio', 10, '', '2019-09-04', 'Disetujui');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `id_supplier` varchar(5) NOT NULL,
  `nama_supplier` varchar(20) NOT NULL,
  `no_telp` varchar(13) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`id_supplier`, `nama_supplier`, `no_telp`, `alamat`) VALUES
('SP001', 'Gunawan', '082354265776', 'Karangpandan'),
('SP002', 'Angga', '098765234567', 'Sukoharjo'),
('SP003', 'Wisnu', '086543456765', 'Karanganyar');

-- --------------------------------------------------------

--
-- Table structure for table `unit_kerja`
--

CREATE TABLE `unit_kerja` (
  `id_uk` varchar(5) NOT NULL,
  `nama_uk` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unit_kerja`
--

INSERT INTO `unit_kerja` (`id_uk`, `nama_uk`) VALUES
('UK001', 'D3 Akuntansi'),
('UK002', 'D3 Keuangan dan Perbankan'),
('UK003', 'D3 Manajemen Pemasaran'),
('UK004', 'D3 Teknik Informatika'),
('UK005', 'D3 Kebidanan'),
('UK006', 'D3 Teknik Kimia');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` varchar(5) NOT NULL,
  `id_uk` varchar(5) DEFAULT NULL,
  `username` varchar(20) NOT NULL,
  `password` text NOT NULL,
  `nama` varchar(50) NOT NULL,
  `nip` varchar(20) NOT NULL,
  `jabatan` varchar(50) NOT NULL,
  `peran` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `id_uk`, `username`, `password`, `nama`, `nip`, `jabatan`, `peran`) VALUES
('KP001', NULL, 'admin', 'admin', 'Administrator', '199107082009010201', 'Administrator', 'Admin'),
('KP002', NULL, 'Direktur', 'direktur', 'Drs. Santoso Tri Hananto, M.Si., Ak.', '196909224199401001', 'Direktur', 'Pimpinan'),
('KP003', NULL, 'Wadir Satu', 'Wadir', 'Agus Dwi Priyanto, S.S.,M.Call', '197408182000121001', 'Wakil Direktur Bidang Akademik', 'Karyawan'),
('KP004', NULL, 'Wadir Dua', 'wadir', 'Abdul Aziz, S.Kom., M.Cs.', '198104132005011001', 'Wakil Direktur BU dan Keuangan', 'Karyawan'),
('KP005', NULL, 'TataUsaha', 'tatausaha', 'Wardiyanto, S.H., M.H.', '196601151986011001', 'Ka. Seksi Tata Usaha', 'Pimpinan'),
('KP006', 'UK001', 'Fitri', 'Fitri', 'Fitri Ardyanti', '199811252009010902', 'Sekretaris', 'Karyawan'),
('KP007', 'UK005', 'Era', 'Era', 'Era Waldini', '675432145676543234', 'Sekretaris', 'Karyawan');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`),
  ADD KEY `id_jenis_barang` (`id_jenis_barang`);

--
-- Indexes for table `brg_keluar`
--
ALTER TABLE `brg_keluar`
  ADD PRIMARY KEY (`id_brg_keluar`),
  ADD KEY `id_pengajuan` (`id_pengajuan`),
  ADD KEY `id_barang` (`id_barang`);

--
-- Indexes for table `brg_masuk`
--
ALTER TABLE `brg_masuk`
  ADD PRIMARY KEY (`id_brg_masuk`),
  ADD KEY `id_barang` (`id_barang`),
  ADD KEY `id_supplier` (`id_supplier`);

--
-- Indexes for table `jenis_barang`
--
ALTER TABLE `jenis_barang`
  ADD PRIMARY KEY (`id_jenis_barang`);

--
-- Indexes for table `pengajuan`
--
ALTER TABLE `pengajuan`
  ADD PRIMARY KEY (`id_pengajuan`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`id_supplier`);

--
-- Indexes for table `unit_kerja`
--
ALTER TABLE `unit_kerja`
  ADD PRIMARY KEY (`id_uk`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `id_uk` (`id_uk`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `barang`
--
ALTER TABLE `barang`
  ADD CONSTRAINT `barang_ibfk_1` FOREIGN KEY (`id_jenis_barang`) REFERENCES `jenis_barang` (`id_jenis_barang`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `brg_keluar`
--
ALTER TABLE `brg_keluar`
  ADD CONSTRAINT `brg_keluar_ibfk_1` FOREIGN KEY (`id_pengajuan`) REFERENCES `pengajuan` (`id_pengajuan`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `brg_keluar_ibfk_2` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `brg_masuk`
--
ALTER TABLE `brg_masuk`
  ADD CONSTRAINT `brg_masuk_ibfk_1` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `brg_masuk_ibfk_2` FOREIGN KEY (`id_supplier`) REFERENCES `supplier` (`id_supplier`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `pengajuan`
--
ALTER TABLE `pengajuan`
  ADD CONSTRAINT `pengajuan_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`id_uk`) REFERENCES `unit_kerja` (`id_uk`) ON DELETE SET NULL ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
