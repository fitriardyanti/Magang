<?php if(! defined('BASEPATH')) exit('Akses langsung tidak diperbolehkan'); 

class Simple_login {
	// SET SUPER GLOBAL
	var $CI = NULL;
	public function __construct() {
		$this->CI =& get_instance();
	}
	// Fungsi login
	public function login($username, $password) {
		$query = $this->CI->db->get_where('User',array('username'=>$username));
		if($query->num_rows() < 1){
			$this->CI->session->set_flashdata('sukses','Mohon Maaf Anda Belum Terdaftar');
			redirect(base_url('index.php/login'));
		}else if($query->row()->password!=$password){
			$this->CI->session->set_flashdata('sukses','Oops... Username/Password Salah');
			redirect(base_url('index.php/login'));
		}else if($query->row()->peran=='Admin'){
			$row 	= $this->CI->db->query('SELECT * FROM User where username = "'.$username.'"');
			$id = $row->row()->id_user;
			$this->CI->session->set_userdata('username', $username);
			$this->CI->session->set_userdata('id_login', uniqid(rand()));
			$this->CI->session->set_userdata('id_user', $id);
			redirect(base_url('index.php/User/tampil_data'));
		}else if($query->row()->peran=='Karyawan'){
			$row 	= $this->CI->db->query('SELECT * FROM User where username = "'.$username.'"');
			$id = $row->row()->id_user;
			$this->CI->session->set_userdata('username', $username);
			$this->CI->session->set_userdata('id_login', uniqid(rand()));
			$this->CI->session->set_userdata('id_user', $id);
			redirect(base_url('index.php/Pengajuan/tampil_data2'));
		} else {
			$row 	= $this->CI->db->query('SELECT * FROM User where username = "'.$username.'"');
			$id = $row->row()->id_user;
			$this->CI->session->set_userdata('username', $username);
			$this->CI->session->set_userdata('id_login', uniqid(rand()));
			$this->CI->session->set_userdata('id_user', $id);
			redirect(base_url('index.php/Pengajuan/tampil_data3'));
		}
		return false;
	}

	// Proteksi halaman
	public function cek_login() {
		if($this->CI->session->userdata('username') == '') {
			$this->CI->session->set_flashdata('sukses','Anda belum login');
			redirect(base_url('index.php/login'));
		}
	}
	// Fungsi logout
	public function logout() {
		$this->CI->session->unset_userdata('username');
		$this->CI->session->unset_userdata('id_login');
		$this->CI->session->unset_userdata('id_user');
		$this->CI->session->set_flashdata('sukses','Anda berhasil logout');
		redirect(base_url('index.php/login'));
	}
}