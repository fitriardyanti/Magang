<?php
class Template {
	//ci instance
	private $CI;
	//template Data
	var $template_data = array();

	public function __construct() 
	{
		$this->CI =& get_instance();
	}

	function set($content_area, $value)
	{
		$this->template_data[$content_area] = $value;
		//[$snk]mengisi indeks array, indeks asosiatif
		// $value untuk memberi value
	}

	function load($template = ''/*nama file template*/, $name ='' /*nama variabel yang akan dipanggil di view*/, $view = ''/*nama view, view yang akan dilempar ke template itu apa*/ , $view_data = array() /*nama data yang mau dilempar, kalogaada gausah*/, $return = FALSE)
	{
		$this->set($name , $this->CI->load->view($view, $view_data, TRUE));
	   
		$this->CI->load->view('layouts/'.$template, $this->template_data /*lempar data*/);
	}
                               
}
?>