<?php
class Model_Barang extends CI_Model {

    public $id_barang;
    public $nama_barang;
    public $nama_jenis_barang;
    public $stock;

    public function GetJoinBarang()
    {
            $this->db->select('*');
            $this->db->from('barang');
            $this->db->join('jenis_barang','barang.id_jenis_barang = jenis_barang.id_jenis_barang');
            $query = $this->db->get();
            return $query;
    }

    public function insert($data)
    {
        $this->db->insert('barang', $data);
    }
        
    public function GetAllBarang()
    {
        $query = $this->db->get('barang');
        return $query;
    }

    public function get_detail($id_barang)
        {
            $this->db->select('*');
            $this->db->from('barang');
            $this->db->join('jenis_barang','barang.id_jenis_barang = jenis_barang.id_jenis_barang');
            $query = $this->db->get_where('', array('id_barang' => $id_barang));
            return $query;
        }

    public function get_tocart()
        {
            $this->db->select('*');
            $this->db->from('barang');
            $this->db->join('jenis_barang','barang.id_jenis_barang = jenis_barang.id_jenis_barang');
            $query = $this->db->get();
            return $query;
        }

    public function edit_data($id_barang)
    {      
        $data = array(
                    'id_barang' => $this->input->post('id_barang'),
                    'nama_barang' => $this->input->post('nama_barang'),
                    'id_jenis_barang' => $this->input->post('id_jenis_barang'),
                    'stock' => $this->input->post('stock'),
                    'satuan' => $this->input->post('satuan')
            );
        $this->db->where('id_barang', $id_barang);
        $this->db->update('barang', $data);
    }

    public function hapus_data($id_barang)
    {
        $this->db->delete('barang', array('id_barang' => $id_barang));
    }

    public function create_id()   
    {
        $this->db->select('RIGHT(barang.id_barang,4) as kode', FALSE);
        $this->db->order_by('id_barang','DESC');    
        $this->db->limit(1);    
        $query = $this->db->get('barang');   
        if($query->num_rows() <> 0)
        {         
            $data = $query->row();      
            $kode = intval($data->kode) + 1;    
        }
        else {        
                $kode = 1;    
             }

        $kodemax = str_pad($kode, 4, "0", STR_PAD_LEFT); 
        $kodejadi = "B".$kodemax; 
        return $kodejadi;  
    }
}
?>