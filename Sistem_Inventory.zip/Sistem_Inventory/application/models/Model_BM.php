<?php
class Model_BM extends CI_Model {

        public $id_brg_masuk;
        public $nama_barang;
        public $jenis_barang;
        public $jumlah_barang;
        public $tgl_masuk;

        public function GetJoinBM()
        {
            $this->db->select('*');
            $this->db->from('brg_masuk');
            $this->db->join('barang', 'barang.id_barang = brg_masuk.id_barang');
            $this->db->join('supplier', 'supplier.id_supplier = brg_masuk.id_supplier');
            $query = $this->db->get();
            return $query;
        }

        public function insert($data)
        {
            $this->db->insert('brg_masuk', $data);
        }

        public function GetAllBM ()
        {
            $query = $this->db->get('brg_masuk');
            return $query;
        }

        public function get_detail($id_brg_masuk)
        {
            $this->db->select('*');
            $this->db->from('brg_masuk');
            $this->db->join('barang', 'barang.id_barang = brg_masuk.id_barang');
            $this->db->join('supplier', 'supplier.id_supplier = brg_masuk.id_supplier');
            $query = $this->db->get_where('', array('id_brg_masuk' => $id_brg_masuk));
            return $query;
        }

        public function update($data, $id_brg_masuk)
        {
            return $this->db->update('brg_masuk', $data, array('id_brg_masuk'=>$id_brg_masuk));
        }

        public function hapus_data($id_brg_masuk)
        {
            return $this->db->delete('brg_masuk', array('id_brg_masuk' => $id_brg_masuk));
        }

        public function create_id()   
    {
        $this->db->select('RIGHT(brg_masuk.id_brg_masuk,3) as kode', FALSE);
        $this->db->order_by('id_brg_masuk','DESC');    
        $this->db->limit(1);    
        $query = $this->db->get('brg_masuk');   
        if($query->num_rows() <> 0)
        {         
            $data = $query->row();      
            $kode = intval($data->kode) + 1;    
        }
        else {        
                $kode = 1;    
             }

        $kodemax = str_pad($kode, 3, "0", STR_PAD_LEFT); 
        $kodejadi = "BM".$kodemax; 
        return $kodejadi;  
    }
}
?>