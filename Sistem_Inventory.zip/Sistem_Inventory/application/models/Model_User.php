<?php
class Model_User extends CI_Model {

        public $id_user;
        public $nama_uk;
        public $username;
        public $password;
        public $nama;
        public $nip;
        public $jabatan;
        public $peran;

        public function GetJoinUser()
        {
            $this->db->select('*');
            $this->db->from('user');
            $this->db->join('unit_kerja','user.id_uk = unit_kerja.id_uk','left');
            $query = $this->db->get();
            return $query;
        }

        public function insert($data)
        {
            $this->db->insert('user', $data);
        }
        
        public function GetAllUser()
        {
            $query = $this->db->get('user');
            return $query;
        }

        public function get_detail($id_user)
        {
            $this->db->select('*');
            $this->db->from('user');
            $this->db->join('unit_kerja','user.id_uk = unit_kerja.id_uk','left');        
            $query = $this->db->get_where('', array('id_user' => $id_user));
            return $query;
        }

    public function edit_data($id_user)
    {      
        $data = array(
                    'id_uk' => $this->input->post('id_uk'),
                    'username' => $this->input->post('username'),
                    'password' => $this->input->post('password'),
                    'nama' => $this->input->post('nama'),
                    'nip' => $this->input->post('nip'),                    
                    'jabatan' => $this->input->post('jabatan'),
                    'peran' => $this->input->post('peran')
            );
        $this->db->where('id_user', $id_user);
        $this->db->update('user', $data);
    }

    public function hapus_data($id_user)
    {
        $this->db->delete('user', array('id_user' => $id_user));
    }

    public function create_id()   
    {
        $this->db->select('RIGHT(user.id_user,3) as kode', FALSE);
        $this->db->order_by('id_user','DESC');    
        $this->db->limit(1);    
        $query = $this->db->get('user');   
        if($query->num_rows() <> 0)
        {         
            $data = $query->row();      
            $kode = intval($data->kode) + 1;    
        }
        else {        
                $kode = 1;    
             }

        $kodemax = str_pad($kode, 3, "0", STR_PAD_LEFT); 
        $kodejadi = "KP".$kodemax; 
        return $kodejadi;  
    }
}
?>