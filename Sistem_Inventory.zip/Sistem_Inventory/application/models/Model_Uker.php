<?php
class Model_Uker extends CI_Model {

        public $id_uk;
		public $nama_uk;
		
         public function GetAllUker()
        {
            $query = $this->db->get('unit_kerja');
            return $query;
        }

        public function input_data($data){
            $this->db->insert('unit_kerja',$data);
        }

        public function get_detail($id_uk)
        {
            $this->db->select('*');
            $this->db->from('unit_kerja');        
            $query = $this->db->get_where('', array('id_uk' => $id_uk));
            return $query;
        }

        public function edit_data($id_uk)
        {      
            $data = array(
                        'id_uk' => $this->input->post('id_uk'),
                        'nama_uk' => $this->input->post('nama_uk'),
                );
            $this->db->where('id_uk', $id_uk);
            $this->db->update('unit_kerja', $data);
        }

        public function hapus_data($id_uk)
        {
            $this->db->delete('unit_kerja', array('id_uk' => $id_uk));
        }

        public function create_id()   
    {
        $this->db->select('RIGHT(unit_kerja.id_uk,3) as kode', FALSE);
        $this->db->order_by('id_uk','DESC');    
        $this->db->limit(1);    
        $query = $this->db->get('unit_kerja');   
        if($query->num_rows() <> 0)
        {         
            $data = $query->row();      
            $kode = intval($data->kode) + 1;    
        }
        else {        
                $kode = 1;    
             }

        $kodemax = str_pad($kode, 3, "0", STR_PAD_LEFT); 
        $kodejadi = "UK".$kodemax; 
        return $kodejadi;  
    }
}
?>