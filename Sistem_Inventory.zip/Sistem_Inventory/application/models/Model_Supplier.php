<?php
class Model_Supplier extends CI_Model {

    public $id_supplier;
    public $nama_supplier;
    public $no_telp;
    public $alamat;
    
        public function GetAllSupplier()
        {
            $query = $this->db->get('supplier');
            return $query;
        }

        public function input_data($data){
            $this->db->insert('supplier',$data);
        }

        public function get_detail($id_supplier)
        {
            $this->db->select('*');
            $this->db->from('supplier');        
            $query = $this->db->get_where('', array('id_supplier' => $id_supplier));
            return $query;
        }

        public function edit_data($id_supplier)
        {      
            $data = array(
                        'id_supplier' => $this->input->post('id_supplier'),
                        'nama_supplier' => $this->input->post('nama_supplier'),
                        'no_telp' => $this->input->post('no_telp'),
                        'alamat' => $this->input->post('alamat'),
                );
            $this->db->where('id_supplier', $id_supplier);
            $this->db->update('supplier', $data);
        }

        public function hapus_data($id_supplier)
        {
            $this->db->delete('supplier', array('id_supplier' => $id_supplier));
        }

        public function create_id()   
    {
        $this->db->select('RIGHT(supplier.id_supplier,3) as kode', FALSE);
        $this->db->order_by('id_supplier','DESC');    
        $this->db->limit(1);    
        $query = $this->db->get('supplier');   
        if($query->num_rows() <> 0)
        {         
            $data = $query->row();      
            $kode = intval($data->kode) + 1;    
        }
        else {        
                $kode = 1;    
             }

        $kodemax = str_pad($kode, 3, "0", STR_PAD_LEFT); 
        $kodejadi = "SP".$kodemax; 
        return $kodejadi;  
    }
}
?>