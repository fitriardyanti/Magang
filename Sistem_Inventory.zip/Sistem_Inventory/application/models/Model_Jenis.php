<?php
class Model_Jenis extends CI_Model {

    public $id_jenis_barang;
    public $nama_jenis_barang;
    
        public function GetAllJenis()
        {
            $query = $this->db->get('jenis_barang');
            return $query;
        }

        public function input_data($data){
            $this->db->insert('jenis_barang',$data);
        }

        public function get_detail($id_jenis_barang)
        {
            $this->db->select('*');
            $this->db->from('jenis_barang');        
            $query = $this->db->get_where('', array('id_jenis_barang' => $id_jenis_barang));
            return $query;
        }

        public function edit_data($id_jenis_barang)
        {      
            $data = array(
                        'id_jenis_barang' => $this->input->post('id_jenis_barang'),
                        'nama_jenis_barang' => $this->input->post('nama_jenis_barang'),
                );
            $this->db->where('id_jenis_barang', $id_jenis_barang);
            $this->db->update('jenis_barang', $data);
        }

        public function hapus_data($id_jenis_barang)
        {
            $this->db->delete('jenis_barang', array('id_jenis_barang' => $id_jenis_barang));
        }

        public function create_id()   
    {
        $this->db->select('RIGHT(jenis_barang.id_jenis_barang,3) as kode', FALSE);
        $this->db->order_by('id_jenis_barang','DESC');    
        $this->db->limit(1);    
        $query = $this->db->get('jenis_barang');   
        if($query->num_rows() <> 0)
        {         
            $data = $query->row();      
            $kode = intval($data->kode) + 1;    
        }
        else {        
                $kode = 1;    
             }

        $kodemax = str_pad($kode, 3, "0", STR_PAD_LEFT); 
        $kodejadi = "JB".$kodemax; 
        return $kodejadi;  
    }
}
?>