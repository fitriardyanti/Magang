<?php
class Model_Pengajuan extends CI_Model {

    public $id_pengajuan;
    public $nama;
    public $nama_barang;
    public $jml_barang;
    public $tgl_pengajuan;
    public $status;

    public function GetJoinPengajuan()
    {
            $this->db->select('*');
            $this->db->from('pengajuan');
            $this->db->join('user','pengajuan.id_user = user.id_user','left');
            $this->db->join('unit_kerja','user.id_uk = unit_kerja.id_uk','left');
            $query = $this->db->get();
            return $query;
    }

    public function insert($data)
    {
        $this->db->insert('pengajuan', $data);
    }
        
    public function GetAllPengajuan()
    {
        $query = $this->db->get('pengajuan');
        return $query;
    }

    public function status($id_pengajuan)
    {
        $this->db->select('status');
        $this->db->where('id_pengajuan',$id_pengajuan);
        $query=$this->db->get('pengajuan');
        return $query->result();
    }

    public function update_status($where,$data,$table)
    {
        $this->db->where($where);
        $query=$this->db->update($table,$data);
        return $query;
    }
    public function SpesifikPengajuan()
    {
        $id_user = $this->session->userdata('id_user');
        $this->db->select('*');
        $this->db->from('pengajuan');        
        $query = $this->db->get_where('', array('id_user' => $id_user));
        return $query;
    }

    public function JoinSpesifikPengajuan()
    {
            $id_user = $this->session->userdata('id_user');
            $this->db->select('*');
            $this->db->from('pengajuan');
            $this->db->join('user','pengajuan.id_user = user.id_user','left');
            $this->db->join('unit_kerja','user.id_uk = unit_kerja.id_uk','left');
            $query = $this->db->get_where('', array('user.id_user' => $id_user));
            return $query;
    }

    public function get_edit_detail_pengajuan($id_detail)
        {
            $this->db->select('*');
            $this->db->from('detail_pengajuan');
            $this->db->join('pengajuan','pengajuan.id_pengajuan = detail_pengajuan.id_pengajuan');
            $this->db->join('barang','detail_pengajuan.id_barang = barang.id_barang');                
            $query = $this->db->get_where('', array('id_detail' => $id_detail));
            return $query;
        }

    public function get_detail($id_detail)
        {
            $this->db->select('*');
            $this->db->from('detail_pengajuan');
            $this->db->join('barang','detail_pengajuan.id_barang = barang.id_barang','left');                
            $query = $this->db->get_where('', array('id_detail' => $id_detail));
            return $query;
        }

    public function get_detail_pengajuan($id_pengajuan)
        {
            $this->db->select('*');
            $this->db->from('detail_pengajuan');
            $this->db->join('pengajuan','pengajuan.id_pengajuan = detail_pengajuan.id_pengajuan');
            $this->db->join('barang','detail_pengajuan.id_barang = barang.id_barang');
            $this->db->join('user','pengajuan.id_user = user.id_user');
            $this->db->join('unit_kerja','user.id_uk = unit_kerja.id_uk');                
            $query = $this->db->get_where('', array('pengajuan.id_pengajuan' => $id_pengajuan));
            return $query;
        }

        public function get_detail_after($id_detail)
        {
            $this->db->select('*');
            $this->db->from('detail_pengajuan');
            $this->db->join('pengajuan','pengajuan.id_pengajuan = detail_pengajuan.id_pengajuan');
            $this->db->join('barang','detail_pengajuan.id_barang = barang.id_barang');                
            $query = $this->db->get_where('', array('detail_pengajuan.id_detail' => $id_detail));
            return $query;
        }

        public function get_de_pengajuan($id_pengajuan)
        {
            $this->db->select('detail_pengajuan.nama_barang,detail_pengajuan.jml_barang,detail_pengajuan.id_barang,barang.satuan');
            $this->db->from('detail_pengajuan');
            $this->db->join('pengajuan','pengajuan.id_pengajuan = detail_pengajuan.id_pengajuan');
            $this->db->join('barang','detail_pengajuan.id_barang = barang.id_barang');                
            $query = $this->db->get_where('', array('pengajuan.id_pengajuan' => $id_pengajuan));
            return $query;
        }
        public function get_user($id_pengajuan)
        {
            $this->db->select('user.nama');
            $this->db->from('pengajuan');
            $this->db->join('user','pengajuan.id_user = user.id_user');                
            $query = $this->db->get_where('', array('pengajuan.id_pengajuan' => $id_pengajuan));
            return $query;
        }

    /*public function edit_detail($id_detail)
        {
            $this->db->select('*');
            $this->db->from('detail_pengajuan');
            $this->db->join('pengajuan','pengajuan.id_pengajuan = detail_pengajuan.id_pengajuan');
            $this->db->join('barang','detail_pengajuan.id_barang = barang.id_barang');                
            $query = $this->db->get_where('', array('id_detail' => $id_detail));
            return $query;
        }*/


    public function edit_data($id_detail)
    {      
        $data = array(
                    'id_barang' => $this->input->post('id_barang'),
                    'jml_barang' => $this->input->post('jml_barang')
            );
        $this->db->where('id_detail', $id_detail);
        $this->db->update('detail_pengajuan', $data);
    }

    public function hapus_data($id_pengajuan)
    {
        $this->db->delete('pengajuan', array('id_pengajuan' => $id_pengajuan));
    }

    public function create_id()   
    {
        $this->db->select('RIGHT(pengajuan.id_pengajuan,4) as kode', FALSE);
        $this->db->order_by('id_pengajuan','DESC');    
        $this->db->limit(1);    
        $query = $this->db->get('pengajuan');   
        if($query->num_rows() <> 0)
        {         
            $data = $query->row();      
            $kode = intval($data->kode) + 1;    
        }
        else {        
                $kode = 1;    
             }

        $kodemax = str_pad($kode, 4, "0", STR_PAD_LEFT); 
        $kodejadi = "P".$kodemax; 
        return $kodejadi;  
    }
}
?>