<?php
class Model_BK extends CI_Model {

        public $id_brg_keluar;
        public $id_user;
        public $nama_barang;
        public $jumlah_barang;
        public $tgl_pengambilan;

        public function GetJoinBK()
        {
            $this->db->select('*');
            $this->db->from('brg_keluar');
            $this->db->join('barang', 'brg_keluar.id_barang = barang.id_barang');
            $this->db->join('pengajuan', 'brg_keluar.id_pengajuan = pengajuan.id_pengajuan');
            $this->db->join('user','pengajuan.id_user = user.id_user');
            $this->db->order_by("id_brg_keluar", "asc");
            $query = $this->db->get();
            return $query;
        }

        public function insert($data)
        {
            $this->db->insert('brg_keluar', $data);
        }

        public function GetAllBK()
        {
            $query = $this->db->get('brg_keluar');
            return $query;
        }

        public function get_detail($id_brg_keluar)
        {
            $this->db->select('*');
            $this->db->from('brg_keluar');
            $this->db->join('barang', 'barang.id_barang = brg_keluar.id_barang','left');
            $this->db->join('pengajuan', 'pengajuan.id_pengajuan = brg_keluar.id_pengajuan','left');
            $this->db->join('user','user.id_user = pengajuan.id_user','left');
            $query = $this->db->get_where('', array('id_brg_keluar' => $id_brg_keluar));
            return $query;
        }

        public function update($data, $id_brg_keluar)
        {
            return $this->db->update('brg_keluar', $data, array('id_brg_keluar'=>$id_brg_keluar));
        }

        public function hapus_data($id_brg_keluar)
        {
            return $this->db->delete('brg_keluar', array('id_brg_keluar' => $id_brg_keluar));
        }

        public function create_id()   
    {
        $this->db->select('RIGHT(brg_keluar.id_brg_keluar,3) as kode', FALSE);
        $this->db->order_by('id_brg_keluar','DESC');    
        $this->db->limit(1);    
        $query = $this->db->get('brg_keluar');   
        if($query->num_rows() <> 0)
        {         
            $data = $query->row();      
            $kode = intval($data->kode) + 1;    
        }
        else {        
                $kode = 1;    
             }

        $kodemax = str_pad($kode, 3, "0", STR_PAD_LEFT); 
        $kodejadi = "BK".$kodemax; 
        return $kodejadi;  
    }
}
?>