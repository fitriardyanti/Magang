<div class="row-fluid">
  <!-- block -->
<div class="block">
    <div class="navbar navbar-inner block-header">
        <div class="muted pull-left">Update Data User</div>
    </div>
    <div class="block-content collapse in">
        <div class="span12">
    <?php
    echo form_open('User/tambah_data');
    ?>
    </div>
  <table>
    <tr>
      <td><label>Id User</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $id_user = array(
              'name'          => 'id_user',
              'id'            => 'id_user',
              'value'         => $id_auto,             
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%',
              'readonly'      => 'readonly'
            );

        echo form_input($id_user);
        echo form_error('id_user'); 
        ?>
      </div></td>
    </tr>
    <tr>
      <td><label>Sub Unit</label></td>
      <td>:</td>
      <td>
      <div class="col-sm-9">      
        <?php
        foreach ($query->result_array() as $row) 
        {
          $options[$row['id_uk']] = $row['nama_uk'];
        }
        echo form_dropdown('id_uk', $options, '');
        ?>
      </div></td>
    </tr>
    <tr>
      <td><label>Username</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $username = array(
              'name'          => 'username',
              'id'            => 'username',
              'placeholder'   => 'Username',
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%'
            );
      echo form_input($username);
      echo form_error('username'); 
      ?>
      </div></td>
    </tr>
    <tr>
      <td><label>Password</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $password = array(
              'name'          => 'password',
              'id'            => 'password',
              'placeholder'   => 'Password',
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%'
            );

      echo form_input($password);
      echo form_error('password'); 
      ?>
      </div></td>
    </tr>
    <tr>
      <td><label>Nama</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $nama = array(
              'name'          => 'nama',
              'id'            => 'nama',
              'placeholder'   => 'Nama',
              'class'         => 'input-material',
              'size'          => '85',
              'style'         => 'width:50%'
            );

      echo form_input($nama);

      echo form_error('nama'); 
      ?>
      </div></td>
  </tr>
  <tr>
      <td><label>NIP</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $nip = array(
              'name'          => 'nip',
              'id'            => 'nip',
              'placeholder'   => 'NIP',
              'class'         => 'input-material',
              'size'          => '85',
              'style'         => 'width:50%'
            );

      echo form_input($nip);
      echo form_error('nip'); 
      ?>
      </div></td>
    </tr>
    <tr>
      <td><label>Jabatan</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $jabatan = array(
              'name'          => 'jabatan',
              'id'            => 'jabatan',
              'placeholder'   => 'Jabatan',
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%'
            );

      echo form_input($jabatan);
      echo form_error('jabatan'); 
      ?>
      </div></td>
    </tr>
    <tr>
      <td><label class="input-material">Peran</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $peran = array(
          'Karyawan'      => 'Karyawan',
          'Pimpinan'      => 'Pimpinan',
          'Admin'         => 'Admin',       
        );
      echo form_dropdown('peran', $peran, 'Karyawan');    
      echo form_error('peran'); 
      ?>
      </div></td>
  </tr>
  <tr>
    <td>
      <div class="form-actions">
      <button type="submit" class="btn btn-primary">Submit</button>

      <a href = "<?php echo site_url()?>/User/tampil_data"> <button type="button" class="btn">Cancel</button></a>
    </div>
    </td>
  </tr>
</table>
<?php form_close(); ?>
</div>
</div>
</div>