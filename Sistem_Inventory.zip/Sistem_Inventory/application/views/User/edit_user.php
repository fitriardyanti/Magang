<div class="row-fluid">
  <!-- block -->
<div class="block">
    <div class="navbar navbar-inner block-header">
        <div class="muted pull-left">Update Data User</div>
    </div>
    <div class="block-content collapse in">
        <div class="span12">
    <?php
    foreach ($user as $edit){
    $tampil_edit = 'User/update/'.$edit['id_user'];
    echo form_open($tampil_edit);
    ?>
    </div>
  <table>
    <tr>
      <td><label class="control-label">Id User</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $id_user = array(
              'name'          => 'id_user',
              'id'            => 'id_user',
              'value'         => $edit['id_user'],              
              'class'         => 'input-material',
              'size'          => '51',
              'style'         => 'width:50%',
              'readonly'      => 'readonly'
            );

        echo form_input($id_user);

        echo form_error('id_user'); 
      ?>
      </div>
      </td>
    </tr>
    <tr>
      <td><label class="control-label">Unit Kerja</label></td>
      <td>:</td>
      <td>

        <?php
      foreach ($query->result_array() as $row) 
      {
        $options[$row['id_uk']]=$row['nama_uk'];
      }
      echo form_dropdown('id_uk', $options, $edit['id_uk']);
      ?>
      </td>
    </tr>
    <tr>
      <td><label class="control-label">Username</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $username = array(
              'name'          => 'username',
              'id'            => 'username',
              'value'         => $edit['username'],
              'class'         => 'input-material',
              'size'          => '51',
              'style'         => 'width:50%'
            );

      echo form_input($username);

      echo form_error('username'); 
      ?>
      </div></td>
    </tr>
    <tr>
      <td><label class="control-label">Password</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $password = array(
              'name'          => 'password',
              'id'            => 'password',
              'value'         => $edit['password'],
              'class'         => 'input-material',
              'size'          => '51',
              'style'         => 'width:50%'
            );

      echo form_input($password);

      echo form_error('password'); 
      ?>
      </div></td>
    </tr>
    <tr>
      <td><label class="control-label">Nama</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $nama = array(
              'name'          => 'nama',
              'id'            => 'nama',
              'value'         => $edit['nama'],
              'class'         => 'input-material',
              'size'          => '51',
              'style'         => 'width:50%'
            );

      echo form_input($nama);

      echo form_error('nama'); 
      ?>
      </div></td>
  </tr>
  <tr>
      <td><label class="control-label">NIP</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $nip = array(
              'name'          => 'nip',
              'id'            => 'nip',
              'value'         => $edit['nip'],
              'class'         => 'input-material',
              'size'          => '51',
              'style'         => 'width:50%'
            );

      echo form_input($nip);

      echo form_error('nip'); 
      ?>
      </div></td>
    </tr>
    <tr>
      <td><label class="control-label">Jabatan</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $jabatan = array(
              'name'          => 'jabatan',
              'id'            => 'jabatan',
              'value'         => $edit['jabatan'],
              'class'         => 'input-material',
              'size'          => '51',
              'style'         => 'width:50%'
            );

      echo form_input($jabatan);

      echo form_error('jabatan'); 
      ?>
      </div></td>
    </tr>
    <tr>
      <td><label class="control-label">Peran</label></td>
      <td>:</td>
      <td>
        <?php
        $peran = array(
          'Karyawan'      => 'Karyawan',
          'Pimpinan'      => 'Pimpinan',
          'Admin'         => 'Admin',       
        );
      echo form_dropdown('peran', $peran, 'Karyawan');
    
      echo form_error('peran'); }
      ?>
      </td>
  </tr>
  <tr>
    <td>
      <div class="form-actions">
      <button type="submit" class="btn btn-primary">Update</button>

      <a href = "<?php echo site_url()?>/User/tampil_data"> <button type="button" class="btn">Cancel</button></a>
      </div>
    </td>
  </tr>
</table>
<?php form_close(); ?>
</div>
</div>
</div>
