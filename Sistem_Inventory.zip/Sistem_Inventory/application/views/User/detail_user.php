<div class="row-fluid">
<div class="block">
    <div class="navbar navbar-inner block-header">
        <div class="muted pull-left">Detail Data User</div>
    </div>
    <div class="block-content collapse in">
        <div class="span12">
          <?php
    $template = array(
                'table_open' => '<table class="table table-striped table-hover">'
                );

                $this->table->set_template($template);

                $this->table->set_heading('ID User','Nama Unit Kerja', 'Nama',' NIP', 'Jabatan');
                
                foreach ($query->result_array() as $row) 
                {
                        $this->table->add_row(
                                                $row['id_user'],
                                                $row['nama_uk'],                                               
                                                $row['nama'],
                                                $row['nip'],
                                                $row['jabatan']                                                
                                              );
                }

                echo $this->table->generate();
                ?>
        <br>
        <a href = '<?php echo base_url()?>index.php/User/tampil_data' > 
        <button class="btn btn-primary">Back</button></a>
    </div>
        </div>
    </div>
</div>            