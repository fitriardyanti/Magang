<!DOCTYPE html>
<html class="no-js">
    
    <head>
        <title>Admin Home Page</title>
        <!-- Bootstrap -->
        <link href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="<?php echo base_url();?>assets/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="<?php echo base_url();?>assets/vendors/easypiechart/jquery.easy-pie-chart.css" rel="stylesheet" media="screen">
        <link href="<?php echo base_url();?>assets/assets/styles.css" rel="stylesheet" media="screen">
        <!-- Favicon -->
        <link rel="shortcut icon" href="<?php echo base_url();?>assets_template/img/favicon.ico">
        <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <script src="<?php echo base_url();?>assets/vendors/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    </head>
    
    <body>
        <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container-fluid">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                    </a>
                    <a class="brand" href="#">Page Admin</a>
                    <div class="nav-collapse collapse">
                        <ul class="nav pull-right">
                            <li class="dropdown">
                                <a href="#" role="button" class="dropdown-toggle" data-toggle="dropdown"> <i class="icon-user"></i> 
                                    <?php
                                        echo $this->session->userdata("username");
                                    ?>  
                                <i class="caret"></i>

                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a tabindex="-1" href="<?php echo base_url()?>index.php/user/Logout">Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row-fluid">
                <div class="span3" id="sidebar">
                    <ul class="nav nav-list bs-docs-sidenav nav-collapse collapse">
                        <li>
                            <a href="<?php echo base_url()?>index.php/User/tampil_data"><i class="icon-chevron-right"></i> Dashboard</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url()?>index.php/User/tambah_data"><i class="icon-chevron-right"></i> Tambah User</a>
                        </li>                        
                        <li>
                            <a href="<?php echo base_url()?>index.php/Pengajuan/tampil_data"><i class="icon-chevron-right"></i> Pengajuan</a>
                        </li>                        
                        <li>
                            <a href="<?php echo base_url()?>index.php/Barang_Masuk/tampil_data"><i class="icon-chevron-right"></i> Barang Masuk</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url()?>index.php/Barang_Keluar/tampil_data"><i class="icon-chevron-right"></i> Barang Keluar</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url()?>index.php/Barang/tampil_data"><i class="icon-chevron-right"></i> Barang</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url()?>index.php/Unit_Kerja/tampil_data"> Sub Unit</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url()?>index.php/Supplier/tampil_data"> Supplier</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url()?>index.php/Jenis_Barang/tampil_data"> Jenis Barang</a>
                        </li>
                    </ul>
                </div>
                
                <!--/span-->
                <div class="span9" id="content">
                    <div class="row-fluid">
                            <div class="navbar">
                                <div class="navbar-inner">
                                    <ul class="breadcrumb">
                                        <i class="icon-chevron-left hide-sidebar"><a href='#' title="Hide Sidebar" rel='tooltip'>&nbsp;</a></i>
                                        <i class="icon-chevron-right show-sidebar" style="display:none;"><a href='#' title="Show Sidebar" rel='tooltip'>&nbsp;</a></i>
                                        <li>
                                            <p>Sistem Inventory</p>   
                                        </li>
                                        
                                    </ul>
                                </div>
                            </div>
                        </div>
                    <div class="row-fluid">                        
                        <?php echo $contents; ?>
                    </div>  
                </div>
            </div>
            <hr>
            <footer>
                <p>&copy; Sekolah Vokasi 2019</p>
            </footer>
        </div>
        <!--/.fluid-container-->
        <script src="<?php echo base_url();?>assets/vendors/jquery-1.9.1.min.js"></script>
        <script src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url();?>assets/vendors/easypiechart/jquery.easy-pie-chart.js"></script>
        <script src="<?php echo base_url();?>assets/assets/scripts.js"></script>
        <script>
        $(function() {
            // Easy pie charts
            $('.chart').easyPieChart({animate: 1000});
        });
        </script>
    </body>

</html>