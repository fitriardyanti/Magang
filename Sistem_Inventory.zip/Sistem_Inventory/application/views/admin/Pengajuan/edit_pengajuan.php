<div class="row-fluid">
<div class="block">
    <div class="navbar navbar-inner block-header">
        <div class="muted pull-left">Detail Data User</div>
    </div>
    <div class="block-content collapse in">
        <div class="span12">
    <?php
    foreach ($pengajuan as $p){
    $tampil_edit = 'pengajuan/update/'.$p['id_pengajuan'];
    echo form_open($tampil_edit);
    ?>
    </div>
  <table>
    <tr>
      <td><label class="input-material">Id pengajuan</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $id_pengajuan = array(
              'name'          => 'id_pengajuan',
              'id'            => 'id_pengajuan',
              'value'         => $p['id_pengajuan'],              
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%'
            );

        echo form_input($id_pengajuan);
        echo form_error('id_pengajuan'); 
      ?>
      </div>
      </td>
    </tr>
    <tr>
      <td><label>Nama</label></td>
      <td>:</td>
      <td>
        <?php
      foreach ($query->result_array() as $row) 
      {
        $options[$row['id_user']]=$row['nama'];
      }
      echo form_dropdown('id_user', $options, $p['id_user']);
      ?>
      </td>
    </tr>
    <tr>
      <td><label>Nama Barang</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $nama_barang = array(
              'name'          => 'nama_barang',
              'id'            => 'nama_barang',
              'value'         => $p['nama_barang'],
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%'
            );

      echo form_input($nama_barang);
      echo form_error('nama_barang'); 
      ?>
      </div></td>
    </tr>
    <tr>
      <td><label>Jumlah Barang</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $jml_barang = array(
              'name'          => 'jml_barang',
              'id'            => 'jml_barang',
              'value'         => $p['jml_barang'],
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%'
            );

      echo form_input($jml_barang);
      echo form_error('jml_barang'); 
      ?>
      </div></td>
    </tr>
    <tr>
      <td><label>Tanggal Pengajuan</label></td>
      <td>:</td>
      <td>
      <?php
      $tgl_pengajuan=array(
             'type'=>'date',
             'name'=>'tgl_pengajuan',
             'value'=> $p['tgl_pengajuan'],
             'id'=>'tgl_pengajuan',
             'size'=>'50',
        );
        echo form_input($tgl_pengajuan);
       echo form_error('tgl_pengajuan'); 
       ?></td>
    </tr>
    <tr>
    <td><label>Status</label></td>
      <td>:</td>
      <td>
        <?php
        $status = array(
              'Disetujui'   => 'Disetujui',
              'Ditolak'     => 'Ditolak',
      );
      echo form_dropdown('status', $status, $p['status']); 
      
      echo form_error('status'); }
      ?>
      </td>
  </tr>
  <tr>
    <td>
    <div class="form-actions">
      <button type="submit" class="btn btn-primary">Update</button>

      <a href = "<?php echo site_url()?>/Pengajuan/tampil_data"> <button type="button" class="btn">Cancel</button>
      </div>
    </td>
  </tr>
</table>
<?php form_close(); ?>
</div>
</div>
</div>