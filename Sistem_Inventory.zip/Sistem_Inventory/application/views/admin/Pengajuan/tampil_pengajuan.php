<div class="row-fluid">
<div class="block">
    <div class="navbar navbar-inner block-header">
        <div class="muted pull-left">Pngajuan</div>
    </div>
    <div class="block-content collapse in">
        <div class="span12">
		<?php
		$template = array(
                'table_open' => '<table class="table table-striped table-hover">'
                );
                $this->table->set_template($template);

                $this->table->set_heading('ID Pengajuan','Sub Unit','Nama','Tgl Pengajuan','Tools');
                
                foreach ($query->result_array() as $row) 
                {
                        $this->table->add_row
                                        (
                                            $row['id_pengajuan'],
                                            $row['nama_uk'],
                                            $row['nama'],                                            
                                            $row['tgl_pengajuan'],
                                            '<a href = "'. base_url('index.php/Pengajuan/detail_data/' 
                                                             .$row['id_pengajuan']).'"<button class="btn"><i class="icon-eye-open"></i> View</button></a>
                                            <a href = "'. base_url('index.php/Pengajuan/update/' 
                                                             .$row['id_pengajuan']).'"<button class="btn btn-primary"><i class="icon-edit icon-white"></i> Update</button></a>
                                            <a href = "'. base_url('index.php/Pengajuan/delete/' 
                                                             .$row['id_pengajuan']).'"<button class="btn btn-danger"><i class="icon-trash icon-white"></i> Delete</button></a>'
                                        );
                }
                echo $this->table->generate();
                ?>
            <a href = "<?php echo base_url()?>index.php/Pengajuan/tambah_data" <button class="btn btn-success"><i class="icon-plus icon-white"></i> Input Pengajuan</button></a>
        </div>
        </div>
    </div>
</div>            