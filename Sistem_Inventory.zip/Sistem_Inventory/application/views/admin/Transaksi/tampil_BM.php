<div class="row-fluid">
<div class="block">
    <div class="navbar navbar-inner block-header">
        <div class="muted pull-left">Barang Masuk</div>
    </div>
    <div class="block-content collapse in">
        <div class="span12">
		<?php
		$template = array(
                'table_open' => '<table class="table table-striped table-hover">'
                );
                $this->table->set_template($template);

                $this->table->set_heading('ID Barang Masuk','Nama Supplier','Nama Barang','Jumlah Barang','Satuan','Tgl Masuk','Tools');
                
                foreach ($query->result_array() as $row) 
                {
                        $this->table->add_row
                                        (
                                            $row['id_brg_masuk'],
                                            $row['nama_supplier'],
                                            $row['nama_barang'],
                                            $row['jml_brg'],
                                            $row['satuan'],
                                            $row['tgl_masuk'],
                                            '<a href = "'. base_url('index.php/Barang_Masuk/detail_data/' 
                                                             .$row['id_brg_masuk']).'"<button class="btn"><i class="icon-eye-open"></i> View</button></a>
                                            <a href = "'. base_url('index.php/Barang_Masuk/update/' 
                                                             .$row['id_brg_masuk']).'"<button class="btn btn-primary"><i class="icon-edit icon-white"></i> Update</button></a>
                                            <a href = "'. base_url('index.php/Barang_Masuk/delete/' 
                                                             .$row['id_brg_masuk']).'"<button class="btn btn-danger"><i class="icon-trash icon-white"></i> Delete</button></a>'
                                        );
                } 
                echo $this->table->generate();
                ?>
                <a href = "<?php echo base_url()?>index.php/Barang_Masuk/tambah_data" <button class="btn btn-success"><i class="icon-plus icon-white"></i> Input Barang Masuk</button></a>
        </div>
        </div>
    </div>
</div>            