<div class="row-fluid">
<div class="block">
    <div class="navbar navbar-inner block-header">
        <div class="muted pull-left">Input Pengajuan</div>
    </div>
    <div class="block-content collapse in">
        <div class="span12">
    <?php
    echo form_open('Barang_Keluar/tambah_data');
    ?>
    </div>
  <table>
    <tr>
      <td><label class="input-material">Id Barang Keluar</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $id_brg_keluar = array(
              'name'          => 'id_brg_keluar',
              'id'            => 'id_brg_keluar',
              'value'         => $id_auto,              
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%'
            );
            echo form_input($id_brg_keluar);
            echo form_error('id_brg_keluar'); 
        ?>
      </div></td>
    </tr>
    <tr>
      <td><label class="input-material">Nama Pengaju</label></td>
      <td>:</td>
      <td>
      <div class="col-sm-9">
        <?php
        foreach ($pengajuan->result_array() as $row) 
        {
          $option[$row['id_pengajuan']]=$row['nama'];
        }
        echo form_dropdown('id_pengajuan', $option, '');
        ?>
      </div></td>
    </tr>
    <tr>
      <td><label class="input-material">Nama Barang</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        foreach ($barang->result_array() as $row) 
        {
          $options[$row['id_barang']]=$row['nama_barang'];
        }
        echo form_dropdown('id_barang', $options, 'Kertas A4');
      ?>
      </div></td>
    </tr>
    <tr>
      <td><label class="input-material">Jumlah Barang</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $jml_brg = array(
              'name'          => 'jml_brg',
              'id'            => 'jml_brg',
              'placeholder'   => 'Jumlah Barang',
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%'
            );
            echo form_input($jml_brg);
            echo form_error('jml_brg'); 
      ?>
      </div></td>
    </tr>
    <tr>
      <td><label class="input-material">Tgl Barang Keluar</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
      <?php
      $tgl_pengambilan=array(
             'type'=>'date',
             'name'=>'tgl_pengambilan',
             'value'  => date("Y-m-d"),
             'id'=>'tgl_pengambilan',
             'size'=>'50',
        );
        echo form_input($tgl_pengambilan);
        echo form_error('tgl_pengambilan'); ?>
      </div></td>
    </tr>
  <tr>
    <td>
      <div class="form-actions">
    <button type="submit" class="btn btn-primary">Submit</button>

      <a href = "<?php echo site_url()?>/Barang_Keluar/tampil_data"> <button type="button" class="btn">Cancel</button></a>
  </div>
    </td>
  </tr>
</table>
<?php form_close(); ?>
</div>
</div>
</div>