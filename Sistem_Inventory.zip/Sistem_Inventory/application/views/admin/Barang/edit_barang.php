<div class="row-fluid">
<div class="block">
    <div class="navbar navbar-inner block-header">
        <div class="muted pull-left">Detail Data User</div>
    </div>
    <div class="block-content collapse in">
        <div class="span12">
    <?php
    foreach ($barang as $b){
    $tampil_edit = 'barang/update/'.$b['id_barang'];
    echo form_open($tampil_edit);
    ?>
    </div>
  <table>
    <tr>
      <td><label>ID Barang</label></td>
      <td>:</td>
      <td>
        <?php
        $id_barang = array(
              'name'          => 'id_barang',
              'id'            => 'id_barang',
              'value'         => $b['id_barang'],
              'maxlength'     => '100',
              'size'          => '50',
              'style'         => 'width:50%'
      );

      echo form_input($id_barang);

      echo form_error('id_barang'); 
      ?>
      </td>
    </tr>
    <tr>
      <td><label>Nama Barang</label></td>
      <td>:</td>
      <td>
        <?php
        $nama_barang = array(
              'name'          => 'nama_barang',
              'id'            => 'nama_barang',
              'value'         => $b['nama_barang'],
              'maxlength'     => '100',
              'size'          => '50',
              'style'         => 'width:50%'
      );

      echo form_input($nama_barang);
      
      echo form_error('nama_barang'); ?></td>
    </tr>
    <tr>
      <td><label>Jenis Barang</label></td>
      <td>:</td>
      <td>
        <?php
      foreach ($query->result_array() as $row) 
      {
        $options[$row['id_jenis_barang']]=$row['nama_jenis_barang'];
      }
      echo form_dropdown('id_jenis_barang', $options, $b['id_jenis_barang']); 
      ?>
      </td>
  </tr>
  <tr>
      <td><label>Stock</label></td>
      <td>:</td>
      <td>
        <?php
        $stock = array(
              'name'          => 'stock',
              'id'            => 'stock',
              'value'         => $b['stock'],
              'maxlength'     => '100',
              'size'          => '50',
              'style'         => 'width:50%'
      );

      echo form_input($stock);
      
      echo form_error('stock');
      ?></td>
    </tr>
    <tr>
      <td><label>Satuan</label></td>
      <td>:</td>
      <td>
        <?php
        $satuan = array(
              'name'          => 'satuan',
              'id'            => 'satuan',
              'value'         => $b['satuan'],
              'maxlength'     => '100',
              'size'          => '50',
              'style'         => 'width:50%'
      );

      echo form_input($satuan);
      
      echo form_error('satuan'); }
      ?></td>
    </tr>
  <tr>
    <td>
      <div class="form-actions">
    <button type="submit" class="btn btn-primary">Update</button>

    <a href = "<?php echo base_url()?>index.php/Barang/tampil_data"> <button type="button" class="btn">Cancel</button></a>
  </div>
    </td>
  </tr>
  </table>
  <?php form_close(); ?>
  </div>
  </div>
</div>      