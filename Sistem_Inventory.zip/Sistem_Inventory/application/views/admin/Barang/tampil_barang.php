<div class="row-fluid">
<div class="block">
    <div class="navbar navbar-inner block-header">
        <div class="muted pull-left">Barang</div>
    </div>
    <div class="block-content collapse in">
        <div class="span12">
		<?php
		$template = array(
                'table_open' => '<table class="table table-striped table-hover">'
                );

                $this->table->set_template($template);

                $this->table->set_heading('ID Barang','Nama Barang','Jenis Barang','Stock','Satuan','Tools');
                
                foreach ($list->result_array() as $row) 
                {
                        $this->table->add_row
                                        (
                                                $row['id_barang'],
                                                $row['nama_barang'],
                                                $row['nama_jenis_barang'],
                                                $row['stock'],
                                                $row['satuan'],
                                                '<a href = "'. base_url('index.php/Barang/detail_data/' 
                                                             .$row['id_barang']).'"<button class="btn"><i class="icon-eye-open"></i> View</button></a>
                                                <a href = "'. base_url('index.php/Barang/update/' 
                                                             .$row['id_barang']).'"<button class="btn btn-primary"><i class="icon-edit icon-white"></i> Update</button></a>
                                                <a href = "'. base_url('index.php/Barang/delete/' 
                                                             .$row['id_barang']).'"<button class="btn btn-danger"><i class="icon-trash icon-white"></i> Delete</button></a>'
                                                
                                        );
                }
                echo $this->table->generate();
                ?>
                <a href = "<?php echo base_url()?>index.php/Barang/tambah_data" <button class="btn btn-success"><i class="icon-plus icon-white"></i> Input Barang</button></a>
            </div>
        </div>
    </div>
</div>            