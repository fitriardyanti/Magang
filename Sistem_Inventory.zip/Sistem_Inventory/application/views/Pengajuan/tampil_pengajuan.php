<html>
<head>
<title></title>
</head>
<body>
<div class="container">
<div class="row">
	<table>
		<?php
		$template = array(
                'table_open' => '<table class="table table-striped table-hover">'
                );
                $this->table->set_template($template);

                $this->table->set_heading('Nama','Unit Kerja','Tgl Pengajuan','Status','Tools');
                
                foreach ($query->result_array() as $row) 
                {
                        $this->table->add_row
                                        (                                            
                                            $row['nama'],
                                            $row['nama_uk'],
                                            $row['tgl_pengajuan'],
                                            $row['status'],                                       
                                            '<a href = "'. base_url('index.php/Pengajuan/terima/' 
                                                             .$row['id_pengajuan']).'"<button class="btn btn-success">Terima</button></a>   
                                            <a href = "'. base_url('index.php/Pengajuan/tolak/' 
                                                             .$row['id_pengajuan']).'"<button class="btn btn-danger">Tolak</button></a></a>
                                            <a href = "'. base_url('index.php/Pengajuan/detail_data3/' 
                                                             .$row['id_pengajuan']).'"<button class="btn btn-primary">detail</button></a>'
                                        );
                }
                echo $this->table->generate();
                ?>
            </table>
        </div>
    </div>
</body>
</html>