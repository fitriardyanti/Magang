<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
  <div class="container">
  <div class="row">
    <div class="heading text-center">
    <?php
    $hidden = array(
      'status' => 'Menunggu Konfirmasi',
      'tgl_pengajuan'=> date("Y-m-d")
    );
    echo form_open('Pengajuan/tambah_data2','',$hidden);
    
    ?>
    </div>
  <table>
    <tr>
      <td><label class="input-material">Id Pengajuan</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $id_pengajuan = array(
              'name'          => 'id_pengajuan',
              'id'            => 'id_pengajuan',
              'value'         => $id_auto,              
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%'
            );
            echo form_input($id_pengajuan);
            echo form_error('id_pengajuan'); 
        ?>
      </div></td>
    </tr>
    <tr>
      <td><label class="input-material">Nama</label></td>
      <td>:</td>
      <td>
      <div class="col-sm-9">
        <?php
        foreach ($query->result_array() as $row) 
        {
          $options[$row['id_user']]=$row['nama'];
        }
        // $data=$this->session->all_userdata();
        // echo "<pre>";
        //       print_r($data);
        //       echo "<pre>";
        //       exit();
        echo form_dropdown('id_user', $options, $this->session->userdata('id_user'),"disabled");
        ?>
      </div></td>
    </tr>
    <tr>
      <td><label class="input-material">Nama Barang</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $nama_barang = array(
              'name'          => 'nama_barang',
              'id'            => 'nama_barang',
              'placeholder'   => 'Nama Barang',
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%'
            );
            echo form_input($nama_barang);
            echo form_error('nama_barang'); 
      ?>
      </div></td>
    </tr>
    <tr>
      <td><label class="input-material">Jumlah Barang</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $jml_barang = array(
              'name'          => 'jml_barang',
              'id'            => 'jml_barang',
              'placeholder'   => 'Jumlah Barang',
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%'
            );
            echo form_input($jml_barang);
            echo form_error('jml_barang'); 
      ?>
      </div></td>
    </tr>
  <tr>
    <td>
    <button type="submit" class="btn btn-primary">Submit</button>
    </td>
  </tr>
</table>
<?php form_close(); ?>
</div>
</div>
</body>
</html>