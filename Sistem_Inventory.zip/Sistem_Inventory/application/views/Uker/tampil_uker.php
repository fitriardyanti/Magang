<div class="row-fluid">
<div class="block">
    <div class="navbar navbar-inner block-header">
        <div class="muted pull-left">Sub Unit</div>
    </div>
    <div class="block-content collapse in">
        <div class="span12"> 
        <?php
        $template = array(
                'table_open' => '<table class="table table-striped table-hover">'
                );

                $this->table->set_template($template);

                $this->table->set_heading('ID Sub Unit','Nama Sub Unit','Tools');
                
                foreach ($query->result_array() as $row) 
                {
                        $this->table->add_row
                                        (
                                                $row['id_uk'],
                                                $row['nama_uk'],                           
                                                '<a href = "'. base_url('index.php/Unit_Kerja/update/' 
                                                             .$row['id_uk']).'"<button class="btn btn-primary"><i class="icon-edit icon-white"></i> Update</button></a>
                                                <a href = "'. base_url('index.php/Unit_Kerja/delete/' 
                                                             .$row['id_uk']).'"<button class="btn btn-danger"><i class="icon-trash icon-white"></i> Delete</button></a>'
                                                
                                        );
                }
                echo $this->table->generate();
                ?>
                <a href = "<?php echo base_url()?>index.php/Unit_Kerja/tambah_aksi" <button class="btn btn-success"><i class="icon-plus icon-white"></i> Input Sub Unit</button></a>
            </div>
        </div>
    </div>
</div>            