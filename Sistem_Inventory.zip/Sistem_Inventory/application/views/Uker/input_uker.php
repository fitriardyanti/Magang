<div class="row-fluid">
  <!-- block -->
<div class="block">
    <div class="navbar navbar-inner block-header">
        <div class="muted pull-left">Input data Sub Unit</div>
    </div>
    <div class="block-content collapse in">
        <div class="span12">
    <?php
    echo form_open('Unit_Kerja/tambah_aksi');
    ?>
    </div>
  <table>
    <tr>
      <td><label class="input-material">Id Sub Unit</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $id_uk = array(
              'name'          => 'id_uk',
              'id'            => 'id_uk',
              'value'         => $id_auto,              
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%',
              'readonly'      => 'readonly' 
            );

        echo form_input($id_uk);
        echo form_error('id_uk'); 
      ?>
      </div>
      </td>
    </tr>
    <tr>
      <td><label>Nama Unit Kerja</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $nama_uk = array(
              'name'          => 'nama_uk',
              'id'            => 'nama_uk',
              'placeholder'   => 'Nama Unit Kerja',
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%'
            );

      echo form_input($nama_uk);
      echo form_error('nama_uk'); 
      ?>
      </div></td>
    </tr>
  <tr>
    <td>
      <div class="form-actions">
      <button type="submit" class="btn btn-primary">Submit</button>

      <a href = "<?php echo site_url()?>/Unit_Kerja/tampil_data"> <button type="button" class="btn">Cancel</button></a>
    </div>
    </td>
  </tr>
</table>
<?php form_close(); ?>
</div>
</div>
</div>