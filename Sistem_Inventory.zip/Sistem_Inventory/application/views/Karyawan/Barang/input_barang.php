<!doctype html>
<html>
<head>
<title></title>
</head>
<body>
	<div class="container">
	<div class="row">
	<div class="heading text-center">
    <?php
  echo form_open('Barang/tambah_data');
  ?>
  </div>
  <table>
  	<tr>
  		<td><label class="input-material">ID Barang</label></td>
  		<td>:</td>
  		<td>
        <div class="col-sm-9">
  			<?php
  			$id_barang = array(
        			'name'          => 'id_barang',
        			'id'            => 'id_barang',
        			'value'          => $id_auto,
        			'maxlength'     => '10',
        			'size'          => '50',
        			'style'         => 'width:50%'
			);

			echo form_input($id_barang);

			echo form_error('id_barang'); 
			?>
    </div>
  		</td>
  	</tr>
  	<tr>
  		<td><label class="input-material">Nama Barang</label></td>
  		<td>:</td>
  		<td>
        <div class="col-sm-9">
  			<?php
  			$nama_barang = array(
        			'name'          => 'nama_barang',
        			'id'            => 'nama_barang',
        			'placeholder'	  => 'Nama Barang',
        			'maxlength'     => '100',
        			'size'          => '50',
        			'style'         => 'width:50%'
			);

			echo form_input($nama_barang);

			echo form_error('nama_barang'); 
			?>
  		</div></td>
  	</tr>
    <tr>
    	<td><label class="input-material">Jenis Barang</label></td>
    	<td>:</td>
    	<td>
        <div class="col-sm-9">
    		<?php
			foreach ($query->result_array() as $row) 
			{
				$options[$row['id_jenis_barang']]=$row['nama_jenis_barang'];
			}
			echo form_dropdown('id_jenis_barang', $options, 'Kertas');
			?>
    	</div></td>
	</tr>
  <tr>
      <td><label class="input-material">Stock</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $stock = array(
              'name'          => 'stock',
              'id'            => 'stock',
              'placeholder'   => 'stock',
              'maxlength'     => '100',
              'size'          => '50',
              'style'         => 'width:50%'
      );

      echo form_input($stock);
      
      echo form_error('stock'); 
      ?>
      </div></td>
    </tr>
    <tr>
    <td>
    <?php
    echo form_submit('submit', 'Submit');
    ?>
    </td>
  </tr>
  </table>
  <?php form_close(); ?>
</div>
</div>
	</body>
</html>