<html>
<head>
<title></title>
</head>
<body>
<div class="container">
<div class="row">
     <div class="heading text-center">
        <a href = '<?php echo base_url()?>index.php/Barang/tambah_data' > 
        <button class="btn btn-primary">Input Barang</button></a>
    </div>
	<table>
		<?php
		$template = array(
                'table_open' => '<table class="table table-striped table-hover">'
                );

                $this->table->set_template($template);

                $this->table->set_heading('ID Barang','Nama Barang','Jenis Barang','Stock');
                
                foreach ($list->result_array() as $row) 
                {
                        $this->table->add_row
                                        (
                                                $row['id_barang'],
                                                $row['nama_barang'],
                                                $row['nama_jenis_barang'],
                                                $row['stock']
                                        );
                }

                echo $this->table->generate();
                ?>
            </table>
        </div>
    </div>
</body>
</html>
