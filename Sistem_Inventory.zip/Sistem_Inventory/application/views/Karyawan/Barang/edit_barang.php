<html>
<head>
  <title></title>
</head>
<body>
  <div class="container">
  <div class="row">
    <div class="heading text-center">
    <?php
    $tampil_edit = 'Barang/update/'.$id_barang['id__barang'];
    echo form_open($tampil_edit);
    ?>
    </div>
  <table>
    <tr>
      <td><label>ID Barang</label></td>
      <td>:</td>
      <td>
        <?php
        $id_barang = array(
              'name'          => 'id_barang',
              'id'            => 'id_barang',
              'value'         => $barang['id_barang'],
              'maxlength'     => '100',
              'size'          => '50',
              'style'         => 'width:50%'
      );

      echo form_input($id_barang);

      echo form_error('id_barang'); 
      ?>
      </td>
    </tr>
    <tr>
      <td><label>Nama barang</label></td>
      <td>:</td>
      <td>
        <?php
        $nama_barang = array(
              'name'          => 'nama_barang',
              'id'            => 'nama_barang',
              'value'         => $barang['nama_barang'],
              'maxlength'     => '100',
              'size'          => '50',
              'style'         => 'width:50%'
      );

      echo form_input($nama_barang);
      echo form_error('nama_barang'); ?></td>
    </tr>
    <tr>
      <td><label>Jenis Barang</label></td>
      <td>:</td>
      <td>
        <?php
      foreach ($query->result_array() as $row) 
      {
        $options[$row['id_jenis_barang']]=$row['nama_jenis_barang'];
      }
      echo form_dropdown('id_jenis_barang', $options, $barang['id_jenis_barang']); 
      ?>
      </td>
  </tr>
  <tr>
      <td><label>Stock</label></td>
      <td>:</td>
      <td>
        <?php
        $nama_jenis_barang = array(
              'name'          => 'nama_jenis_barang',
              'id'            => 'nama_jenis_barang',
              'value'         => $barang['nama_jenis_barang'],
              'maxlength'     => '100',
              'size'          => '50',
              'style'         => 'width:50%'
      );

      echo form_input($nama_jenis_barang);
      
      echo form_error('nama_jenis_barang');
      ?></td>
    </tr>
  <tr>
    <td>
    <?php
    echo form_submit('submit', 'Update');
    ?>
    </td>
  </tr>
  </table>
  <?php form_close(); ?>
  </div>
    </div>    
</body>
</html>