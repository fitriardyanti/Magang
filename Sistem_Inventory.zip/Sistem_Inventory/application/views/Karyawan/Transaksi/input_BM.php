<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body>
  <div class="container">
  <div class="row">
    <div class="heading text-center">
    <?php
    echo form_open('Barang_Masuk/tambah_data');
    ?>
    </div>
  <table>
    <tr>
      <td><label class="input-material">Id Barang Masuk</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $id_brg_masuk = array(
              'name'          => 'id_brg_masuk',
              'id'            => 'id_brg_masuk',
              'placeholder'   => 'ID Barang Masuk',              
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%'
            );
            echo form_input($id_brg_masuk);
            echo form_error('id_brg_masuk'); 
        ?>
      </div></td>
    </tr>
    <tr>
      <td><label class="input-material">Nama Supplier</label></td>
      <td>:</td>
      <td>
      <div class="col-sm-9">
        <?php
        foreach ($supplier->result_array() as $row) 
        {
          $options[$row['id_supplier']]=$row['nama_supplier'];
        }
        echo form_dropdown('id_supplier', $options, 'Gunawan');
        ?>
      </div></td>
    </tr>
    <tr>
      <td><label class="input-material">Nama Barang</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        foreach ($barang->result_array() as $row) 
        {
          $options[$row['id_barang']]=$row['nama_barang'];
        }
        echo form_dropdown('id_barang', $options, 'Kertas A4');
      ?>
      </div></td>
    </tr>
    <tr>
      <td><label class="input-material">Jumlah Barang</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $jml_brg = array(
              'name'          => 'jml_brg',
              'id'            => 'jml_brg',
              'placeholder'   => 'Jumlah Barang',
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%'
            );
            echo form_input($jml_brg);
            echo form_error('jml_brg'); 
      ?>
      </div></td>
    </tr>
    <tr>
      <td><label class="input-material">Satuan</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $satuan = array(
              'name'          => 'satuan',
              'id'            => 'satuan',
              'placeholder'   => 'Satuan',
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%'
            );
            echo form_input($satuan);
            echo form_error('satuan'); 
      ?>
      </div></td>
    </tr>
    <tr>
      <td><label class="input-material">Tgl Barang Masuk</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
      <?php
      $tgl_masuk=array(
             'type'=>'date',
             'name'=>'tgl_masuk',
             'id'=>'tgl_masuk',
             'size'=>'50',
        );
        echo form_input($tgl_masuk);
        echo form_error('tgl_masuk'); ?>
      </div></td>
    </tr>
  <tr>
    <td>
    <?php
    echo form_submit('submit', 'Submit');
    ?>
    </td>
  </tr>
</table>
<?php form_close(); ?>
</div>
</div>
</body>
</html>