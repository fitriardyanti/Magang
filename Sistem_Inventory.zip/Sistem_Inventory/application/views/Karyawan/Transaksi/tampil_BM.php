<html>
<head>
<title></title>
</head>
<body>
<div class="container">
<div class="row">
	<table>
		<?php
		$template = array(
                'table_open' => '<table class="table table-striped table-hover">'
                );
                $this->table->set_template($template);

                $this->table->set_heading('ID Barang Masuk','Nama Supplier','Nama Barang','Jumlah Barang','Satuan','Tgl Masuk');
                
                foreach ($query->result_array() as $row) 
                {
                        $this->table->add_row
                                        (
                                            $row['id_brg_masuk'],
                                            $row['nama_supplier'],
                                            $row['nama_barang'],
                                            $row['jml_brg'],
                                            $row['satuan'],
                                            $row['tgl_masuk']
                                        );
                }

                echo $this->table->generate();
                ?>
            </table>
        </div>
    </div>
</body>
</html>