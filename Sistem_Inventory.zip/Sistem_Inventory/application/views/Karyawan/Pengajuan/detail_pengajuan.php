<!doctype html>
<html lang="id">
<head>
<title></title>
</head>
<body>
<div class="container">
          <?php
    $template = array(
                'table_open' => '<table class="table table-striped table-hover">'
                );

                $this->table->set_template($template);

                $this->table->set_heading('ID Pengajuan', 'Nama Barang', 'Jumlah Barang','Satuan','Tanggal Pengajuan','status','tools');
                $btn=" ";



                foreach ($query->result_array() as $row) 
                {
                    if ($row['status'] != 'Menunggu Konfirmasi') { 
                    $btn= "<button class='btn btn-primary' disabled>Edit</button>"; 
                }else{
                    $btn= '<a href = "'. base_url('index.php/Pengajuan/update2/' .$row['id_detail']).'"<button class="btn btn-primary">Edit</button></a>';
                    }
                        $this->table->add_row(
                                                $row['id_pengajuan'],
                                                $row['nama_barang'],
                                                $row['jml_barang'],
                                                $row['satuan'],
                                                $row['tgl_pengajuan'],
                                                $row['status'],
                                                $btn
                                              );
                }

                echo $this->table->generate();
                ?>
        <br>
        <a href = '<?php echo base_url()?>index.php/Pengajuan/tampil_data2' > 
        <button class="btn btn-primary">Back</button></a>
    </div>
</body>
</html> 