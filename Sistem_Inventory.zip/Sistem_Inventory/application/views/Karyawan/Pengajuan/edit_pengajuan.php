<html>
<head>
  <title></title>
</head>
<body>
  <div class="container">
  <div class="row">
    <div class="heading text-center">
    <?php
    $tampil_edit = 'pengajuan/update2/'.$detail_pengajuan['id_detail'];
    echo form_open($tampil_edit);
    ?>
    </div>
  <table>
    <tr>
      <td><label>Nama Barang</label></td>
      <td>:</td>
      <td>
        <?php
      foreach ($query->result_array() as $row) 
      {
        $options[$row['id_barang']]=$row['nama_barang'];
      }
      echo form_dropdown('id_barang', $options, $detail_pengajuan['id_barang']);
      ?>
      </td>
    </tr>
    <tr>
      <td><label>Jumlah Barang</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $jml_barang = array(
              'type'          => 'number',
              'name'          => 'jml_barang',
              'id'            => 'jml_barang',
              'value'         => $detail_pengajuan['jml_barang'],
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%'
            );

      echo form_input($jml_barang);
      echo form_error('jml_barang');
      ?>
      </div></td>
    </tr>
  <tr>
    <td>
        <button type="submit" class="btn btn-primary">Update</button>
    </td>
  </tr>
</table>
<?php form_close(); ?>
</div>
</div>
</body>
</html>