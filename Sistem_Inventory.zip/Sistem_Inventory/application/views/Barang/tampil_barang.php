<html>
<head>
<title></title>
</head>
<body>
<div class="container">
<div class="row">
	<table>
		<?php
		$template = array(
                'table_open' => '<table class="table table-striped table-hover">'
                );

                $this->table->set_template($template);

                $this->table->set_heading('ID Barang','Nama Barang','Jenis Barang','Stock','Satuan');
                
                foreach ($list->result_array() as $row) 
                {
                        $this->table->add_row
                                        (
                                                $row['id_barang'],
                                                $row['nama_barang'],
                                                $row['nama_jenis_barang'],
                                                $row['stock'],
                                                $row['satuan']
                                        );
                }

                echo $this->table->generate();
                ?>
            </table>
        </div>
    </div>
</body>
</html>
