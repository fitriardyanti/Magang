<!doctype html>
<html lang="id">
<head>
<title></title>
</head>
<body>
<div class="container">
          <?php
    $template = array(
                'table_open' => '<table class="table table-striped table-hover">'
                );

                $this->table->set_template($template);

                $this->table->set_heading('ID Barang', 'Nama Barang', 'Jenis Barang','stock');
                
                foreach ($query->result_array() as $row) 
                {
                        $this->table->add_row(
                                                $row['id_barang'],
                                                $row['nama_barang'],
                                                $row['nama_jenis_barang'],
                                                $row['stock']
                                              );
                }

                echo $this->table->generate();
                ?>
        <br>
      <a href = '<?php echo base_url()?>index.php/Barang' > 
        <button class="btn btn-primary">Back</button></a>
    </div>
</body>
</html> 