<div class="row-fluid">
  <!-- block -->
<div class="block">
    <div class="navbar navbar-inner block-header">
        <div class="muted pull-left">Update Data Jenis Barang</div>
    </div>
    <div class="block-content collapse in">
        <div class="span12">
    <?php
    $tampil_edit = 'Jenis_Barang/update/'.$jenis_barang['id_jenis_barang'];
    echo form_open($tampil_edit);
    ?>
    </div>
  <table>
    <tr>
      <td><label class="input-material">Id Jenis Barang</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $id_jenis_barang = array(
              'name'          => 'id_jenis_barang',
              'id'            => 'id_jenis_barang',
              'value'         => $jenis_barang['id_jenis_barang'],              
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%'
            );

        echo form_input($id_jenis_barang);
        echo form_error('id_jenis_barang'); 
      ?>
      </div>
      </td>
    </tr>    
    <tr>
      <td><label>Nama Jenis Barang</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $nama_jenis_barang = array(
              'name'          => 'nama_jenis_barang',
              'id'            => 'nama_jenis_barang',
              'value'         => $jenis_barang['nama_jenis_barang'],
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%'
            );

      echo form_input($nama_jenis_barang);
      echo form_error('nama_jenis_barang'); 
      ?>
      </div></td>
    </tr>
  <tr>
    <td>
      <div class="form-actions">
      <button type="submit" class="btn btn-primary">Update</button>

      <a href = "<?php echo site_url()?>/Jenis_Barang/tampil_data"> <button type="button" class="btn">Cancel</button></a>
      </div>
    </td>
  </tr>
</table>
<?php form_close(); ?>
</div>
</div>
</div>
