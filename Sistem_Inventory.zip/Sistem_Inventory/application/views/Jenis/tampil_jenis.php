<div class="row-fluid">
<div class="block">
    <div class="navbar navbar-inner block-header">
        <div class="muted pull-left">Jenis Barang</div>
    </div>
    <div class="block-content collapse in">
        <div class="span12">
        <?php
        $template = array(
                'table_open' => '<table class="table table-striped table-hover">'
                );

                $this->table->set_template($template);

                $this->table->set_heading('id jenis barang','nama jenis barang','Tools');
                
                foreach ($query->result_array() as $row) 
                {
                        $this->table->add_row
                                        (
                                                $row['id_jenis_barang'],
                                                $row['nama_jenis_barang'],                           
                                                '<a href = "'. base_url('index.php/Jenis_Barang/update/' 
                                                             .$row['id_jenis_barang']).'"<button class="btn btn-primary"><i class="icon-edit icon-white"></i> Update</button></a>
                                                <a href = "'. base_url('index.php/Jenis_Barang/delete/' 
                                                             .$row['id_jenis_barang']).'"<button class="btn btn-danger"><i class="icon-trash icon-white"></i> Delete</button></a>'
                                                
                                        );
                }
                echo $this->table->generate();
                ?>
                <a href = "<?php echo base_url()?>index.php/Jenis_Barang/tambah_aksi" <button class="btn btn-success"><i class="icon-plus icon-white"></i> Input Jenis</button></a>
        </div>
        </div>
    </div>
</div>            