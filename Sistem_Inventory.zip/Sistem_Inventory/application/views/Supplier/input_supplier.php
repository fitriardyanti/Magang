<div class="row-fluid">
  <!-- block -->
<div class="block">
    <div class="navbar navbar-inner block-header">
        <div class="muted pull-left">Input Supplier</div>
    </div>
    <div class="block-content collapse in">
        <div class="span12">
    <?php
    echo form_open('Supplier/tambah_aksi');
    ?>
    </div>
  <table>
    <tr>
      <td><label class="input-material">Id Supplier</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $id_supplier = array(
              'name'          => 'id_supplier',
              'id'            => 'id_supplier',
              'value'         => $id_auto,             
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%',
              'readonly'      => 'readonly'
            );

        echo form_input($id_supplier);
        echo form_error('id_supplier'); 
      ?>
      </div>
      </td>
    </tr>
    <tr>
      <td><label>Nama Supplier</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $nama_supplier = array(
              'name'          => 'nama_supplier',
              'id'            => 'nama_supplier',
              'placeholder'   => 'Nama Supplier',
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%'
            );

      echo form_input($nama_supplier);
      echo form_error('nama_supplier'); 
      ?>
      </div></td>
    </tr>
    <tr>
      <td><label>No Telp</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $no_telp = array(
              'name'          => 'no_telp',
              'id'            => 'no_telp',
              'placeholder'   => 'No Telp',
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%'
            );

      echo form_input($no_telp);
      echo form_error('no_telp'); 
      ?>
      </div></td>
    </tr>
    <tr>
      <td><label>Alamat</label></td>
      <td>:</td>
      <td>
        <div class="col-sm-9">
        <?php
        $alamat = array(
              'name'          => 'alamat',
              'id'            => 'alamat',
              'placeholder'   => 'Alamat',
              'class'         => 'input-material',
              'size'          => '50',
              'style'         => 'width:50%'
            );

      echo form_input($alamat);
      echo form_error('alamat'); 
      ?>
      </div></td>
    </tr>
  <tr>
    <td>
      <div class="form-actions">
        <button type="submit" class="btn btn-primary">Submit</button>

        <a href = "<?php echo site_url()?>/Supplier/tampil_data"> <button type="button" class="btn">Cancel</button></a>
      </div>
    </td>
  </tr>
</table>
</div>
</div>
</div>