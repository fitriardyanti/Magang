<div class="row-fluid">
<div class="block">
    <div class="navbar navbar-inner block-header">
        <div class="muted pull-left">Supplier</div>
    </div>
    <div class="block-content collapse in">
        <div class="span12">
		<?php
		$template = array(
                'table_open' => '<table class="table table-striped table-hover">'
                );
                $this->table->set_template($template);

                $this->table->set_heading('ID Uker','Nama Supplier','No Telp','Alamat', 'Tools','');
                
                foreach ($query->result_array() as $row) 
                {
                        $this->table->add_row
                                        (
                                            $row['id_supplier'],
                                            $row['nama_supplier'],
                                            $row['no_telp'],
                                            $row['alamat'],
                                            '<a href = "'. base_url('index.php/Supplier/detail_data/' 
                                                             .$row['id_supplier']).'"<button class="btn"><i class="icon-eye-open"></i> View</button></a>
                                            <a href = "'. base_url('index.php/Supplier/update/' 
                                                             .$row['id_supplier']).'"<button class="btn btn-primary"><i class="icon-edit icon-white"></i> Update</button></a>
                                            <a href = "'. base_url('index.php/Supplier/delete/' 
                                                             .$row['id_supplier']).'"<button class="btn btn-danger"><i class="icon-trash icon-white"></i> Delete</button></a>'
                                        );
                }
                echo $this->table->generate();
                ?>
                <a href = "<?php echo base_url()?>index.php/Supplier/tambah_aksi" <button class="btn btn-success"><i class="icon-plus icon-white"></i> Input Supplier</button></a>
        </div>
        </div>
    </div>
</div>            