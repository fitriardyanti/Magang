<?php
class Supplier extends CI_Controller {

	public function tambah_aksi(){
		/*$this->simple_login->cek_login();*/
		$this->form_validation->set_rules('id_supplier','ID Supplier','required');
		$this->form_validation->set_rules('nama_supplier','Nama Supplier','required');
		$this->form_validation->set_rules('no_telp','No Telp','required');
		$this->form_validation->set_rules('alamat','Alamat Supplier','required');

		if ($this->form_validation->run() == FALSE)
           {
               $data['id_auto'] = $this->Model_Supplier->create_id();
               $data['query'] = $this->Model_Supplier->GetAllSupplier();
               $this->template->set('title', 'Input Data Supplier');
               $this->template->load('admin_layout', 'contents', 'Supplier/input_supplier', $data );
           }
           else
           { 
				$data = array(
           			'id_supplier' => $this->input->post('id_supplier'),
             		'nama_supplier' => $this->input->post('nama_supplier'),
             		'no_telp' => $this->input->post('no_telp'),
             		'alamat' => $this->input->post('alamat'),
				);
			$this->Model_Supplier->input_data($data);
			redirect(base_url('index.php/Supplier/tampil_data'));
            } 
	}

	public function tampil_data()
	{
		//$this->simple_login->cek_login();
        $query = $this->Model_Supplier->GetAllSupplier();
        $data['query'] = $query;
        $this->template->set('title', 'Data Jenis Barang');
		$this->template->load('admin_layout', 'contents', 'Supplier/tampil_supplier', $data );
	}

	public function detail_data($id_supplier)
	{
		/*$this->simple_login->cek_login();*/		
		$query = $this->Model_Supplier->get_detail($id_supplier);
		$data['query'] = $query;
		$this->template->set('title', 'Detail Data Supplier');
		$this->template->load('admin_layout', 'contents', 'Supplier/detail_supplier', $data );
	}

	public function update($id_supplier)
	{
		/*$this->simple_login->cek_login();*/
		$this->form_validation->set_rules('id_supplier','ID Jenis Barang','required');
		$this->form_validation->set_rules('nama_supplier','Nama Supplier','required');
		$this->form_validation->set_rules('no_telp','ID Jenis Barang','required');
		$this->form_validation->set_rules('alamat','Nama Jenis Barang','required');


		if ($this->form_validation->run() == FALSE)
           {
               $data['query'] = $this->Model_Supplier->GetAllSupplier();
               $data['supplier'] = $this->Model_Supplier->get_detail($id_supplier)->row_array();
               $this->template->set('title', 'Update Data Jenis Barang');
			   $this->template->load('admin_layout', 'contents', 'Supplier/edit_supplier', $data );
           }
           else
           { 
				$data = array(
					'id_supplier' => $this->input->post('id_supplier'),
             		'nama_supplier' => $this->input->post('nama_supplier'),
             		'no_telp' => $this->input->post('no_telp'),
             		'alamat' => $this->input->post('alamat'),
				);
            $this->Model_Supplier->edit_data($id_supplier);
			redirect(base_url('index.php/Supplier/tampil_data'));            
            } 
	}

	public function delete($id_supplier)
    {
		/*$this->simple_login->cek_login();*/
		$query = $this->Model_Supplier->hapus_data($id_supplier);
		$data['query'] = $query;
        redirect(base_url('index.php/Supplier/tampil_data'));
	}	

}
?>
