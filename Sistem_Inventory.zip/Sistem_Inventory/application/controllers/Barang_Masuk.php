<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Barang_Masuk extends CI_Controller {
	
	public function tambah_data()
	{
		//$this->simple_login->cek_login();
		$this->form_validation->set_rules('id_brg_masuk', 'ID Barang Masuk', 'required');
		$this->form_validation->set_rules('id_supplier', 'Nama Supplier', 'required');
		$this->form_validation->set_rules('id_barang', 'ID Barang', 'required');
		$this->form_validation->set_rules('jml_brg', 'Jumlah Barang', 'required');
		
		$this->form_validation->set_rules('tgl_masuk', 'Tanggal Masuk', 'required');
		

		if ($this->form_validation->run() == FALSE)
                {
						$data['id_auto'] = $this->Model_BM->create_id();
						$data['brg_masuk'] = $this->Model_BM->GetAllBM();					
                        $data['barang'] = $this->Model_Barang->GetAllBarang();
                        $data['supplier'] = $this->Model_Supplier->GetAllSupplier();
                        $this->template->set('title', 'Input Data Barang Masuk');
                        $this->template->load('admin_layout', 'contents' , 'admin/Transaksi/input_BM', $data);
                }
                else
                {
                $data= array(
    					'id_brg_masuk'=>$this->input->post('id_brg_masuk'),
    					'id_supplier'=>$this->input->post('id_supplier'),
    					'id_barang'=>$this->input->post('id_barang'),
    					'jml_brg'=>$this->input->post('jml_brg'),
    					
    					'tgl_masuk'=>$this->input->post('tgl_masuk')    			
    				);

    			$this->Model_BM->insert($data);
    			redirect(base_url('index.php/Barang_Masuk/tampil_data'));
                       
                }
	}
/*
	public function update($id_brg_masuk)
	{
		$this->form_validation->set_rules('id_brg_masuk', 'ID Barang Masuk', 'required');
		$this->form_validation->set_rules('id_supplier', 'Nama Supplier', 'required');
		$this->form_validation->set_rules('id_barang', 'ID Barang', 'required');
		$this->form_validation->set_rules('jml_brg', 'Jumlah Barang', 'required');
		$this->form_validation->set_rules('tgl_masuk', 'Tanggal Masuk', 'required');		

		if ($this->form_validation->run() == FALSE)
                {
                        $query['barang']= $this->Model_Barang->GetAllBarang()->result_array();
						$query['supplier']= $this->Model_Supplier->get_detail($id_supplier)->result_array();
						$this->template->set('title', 'Update Data Barang Masuk');
						$this->template->load('admin_layout', 'contents' , 'admin/Transaksi/edit_BM', $query);
                }
                else
                {
                    $data= array(
	    			'id_brg_masuk'=>$this->input->post('id_brg_masuk'),
    				'id_supplier'=>$this->input->post('id_supplier'),
    				'id_barang'=>$this->input->post('id_barang'),
    				'jml_brg'=>$this->input->post('jml_brg'),
    				'tgl_masuk'=>$this->input->post('tgl_masuk')	    			
	    			);

	    			$query= $this->Model_BM->update($data, $id_brg_masuk);
	    			if ($query>0) {
	    				$url= base_url("admin/Barang_Masuk/tampil_data");
	    				redirect($url);
	    			}
                }
	}*/

	public function tampil_data()
	{
		$data['query'] = $this->Model_BM->GetJoinBM(); 				
		$this->template->set('title', 'Data Barang Masuk');
		$this->template->load('admin_layout', 'contents' , 'admin/Transaksi/tampil_BM', $data);
	}

	public function tampil_data2()
	{
		$data['query'] = $this->Model_BM->GetJoinBM(); 				
		$this->template->set('title', 'Data Barang Masuk');
		$this->template->load('default_user', 'contents' , 'Transaksi/tampil_BM', $data);
	}

	public function tampil_data3()
	{
		$data['query'] = $this->Model_BM->GetJoinBM(); 				
		$this->template->set('title', 'Data Barang Masuk');
		$this->template->load('default', 'contents' , 'Transaksi/tampil_BM', $data);
	}

	public function update($id_brg_masuk)
	{
		
		$this->form_validation->set_rules('id_brg_masuk', 'ID Barang Masuk', 'required');
		$this->form_validation->set_rules('id_supplier', 'Nama Supplier', 'required');
		$this->form_validation->set_rules('id_barang', 'ID Barang', 'required');
		$this->form_validation->set_rules('jml_brg', 'Jumlah Barang', 'required');
		
		$this->form_validation->set_rules('tgl_masuk', 'Tanggal Masuk', 'required');
		
		if ($this->form_validation->run() == FALSE)
                {
                        $data['brg_masuk'] = $this->Model_BM->get_detail($id_brg_masuk)->result_array();
               			$data['supplier'] = $this->Model_Supplier->GetAllSupplier();
               			$data['barang'] = $this->Model_Barang->GetAllBarang();
                        $this->template->set('title', 'Update Data Paket');
						$this->template->load('admin_layout', 'contents' , 'admin/Transaksi/edit_BM', $data);
                }
                else
                {
                    $data= array(
	    					'id_brg_masuk'=>$this->input->post('id_brg_masuk'),
    						'id_supplier'=>$this->input->post('id_supplier'),
    						'id_barang'=>$this->input->post('id_barang'),
    						'jml_brg'=>$this->input->post('jml_brg'),
    						
    						'tgl_masuk'=>$this->input->post('tgl_masuk')   
	    				);
	    			$query= $this->Model_BM->update($data, $id_brg_masuk);
	    			redirect(base_url('index.php/Barang_Masuk/tampil_data'));
                }
	}	

	public function detail($id_brg_masuk)
	{
		$data['brg_masuk'] = $this->Model_BM->get_detail($id_brg_masuk);
		$this->template->set('title', 'Detail Data paket');
		$this->template->load('default', 'contents' , 'BM/detail_BM', $data);
	}

	public function delete($id_brg_masuk)
    {
    	$query = $this->Model_BM->hapus_data($id_brg_masuk);
		$data['query'] = $query;
		$list = $this->Model_BM->GetJoinBM();
		$data['list'] = $list;
    	redirect(base_url('index.php/Barang_Masuk/tampil_data'));
    }
}