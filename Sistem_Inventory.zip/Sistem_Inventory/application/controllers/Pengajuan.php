<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengajuan extends CI_Controller {

  public function tambah_data()
  {
      $data['barang'] = $this->Model_Barang->get_tocart();            
      $this->template->set('title', 'Form Pengajuan');
      $this->template->load('admin_layout', 'contents', 'admin/Pengajuan/cart_view', $data );
  } 

  public function tambah_data2()
  {
      $data['barang'] = $this->Model_Barang->get_tocart();            
      $this->template->set('title', 'Form Pengajuan');
      $this->template->load('default_user', 'contents', 'Karyawan/Pengajuan/cart_view', $data );
  }

  public function tambah_data3()
  {
      $data['barang'] = $this->Model_Barang->get_tocart();            
      $this->template->set('title', 'Form Pengajuan');
      $this->template->load('default', 'contents', 'Pengajuan/cart_view', $data );
  }     

	public function tampil_data(){
		$data['query'] = $this->Model_Pengajuan->GetAllPengajuan();
		$query = $this->Model_Pengajuan->GetJoinPengajuan();
    $data['query'] = $query;
		$this->template->set('title', 'Home');
		$this->template->load('admin_layout', 'contents' , 'admin/Pengajuan/tampil_pengajuan', $data );
	}

	public function tampil_data2(){
		$data['query'] = $this->Model_Pengajuan->SpesifikPengajuan();
		$query = $this->Model_Pengajuan->JoinSpesifikPengajuan();
        $data['query'] = $query;
		$this->template->set('title', 'Home');
		$this->template->load('default_user', 'contents' , 'Karyawan/Pengajuan/tampil_pengajuan', $data );
	}

  public function tampil_data3(){
    $data['query'] = $this->Model_Pengajuan->GetAllPengajuan();
    $query = $this->Model_Pengajuan->GetJoinPengajuan();
        $data['query'] = $query;
    $this->template->set('title', 'Home');
    $this->template->load('default', 'contents' , 'Pengajuan/tampil_pengajuan', $data );
  }

  public function terima($id_pengajuan){
   // $where=array('id_pengajuan',$id_pengajuan);
    $ganti="";
    $status = $this->Model_Pengajuan->status($id_pengajuan);
    foreach($status as $row){
      switch ($row->status) {
        case 'Menunggu Konfirmasi':
          $ganti="Diterima";
          break;
      }
     
    }
     $data=array(
        'status'=>$ganti
      );
    $this->db->where('id_pengajuan',$id_pengajuan);
    $query=$this->db->update('pengajuan',$data);
    if (!empty($query)) {
    $detail=$this->Model_Pengajuan->get_de_pengajuan($id_pengajuan);
    $user=$this->Model_Pengajuan->get_user($id_pengajuan);
    
    foreach ($detail->result_array() as $dp) {
      //$id_brg_keluar=$this->Model_BK->create_id()//;
    $insert[]=array(
      'id_pengajuan'=> $id_pengajuan,
      'id_barang'=> $dp['id_barang'],
      'jml_brg'=> $dp['jml_barang'],
      'tgl_pengambilan' => date("Y-m-d")
    );
  }
  $this->db->insert_batch('brg_keluar',$insert);
  redirect('pengajuan/tampil_data3');
  //print_r($insert);
   // $id_brg_keluar=$this->Model_BK->create_id();
   //  $data=array(
   //    'id_brg_keluar'=> $id_brg_keluar,
   //    'id_pengajuan'=> $id_pengajuan,
   //    'id_barang'=> [$i]$dp['id_barang'],
   //    'jml_brg'=> [$i]$dp['jml_barang'],
   //    'tgl_pengambilan' => date("Y-m-d")
   //  ); 
    // $keluar=$this->db->insert('brg_keluar',$data);
    // if($keluar>0){
    //   echo "Berhasil";
    // }
    //print_r($data);
    }
    
  }

  public function tolak($id_pengajuan){
   // $where=array('id_pengajuan',$id_pengajuan);
    $no="";
    $status = $this->Model_Pengajuan->status($id_pengajuan);
    foreach($status as $row){
      switch ($row->status) {
        case 'Menunggu Konfirmasi':
          $no="Ditolak";
          break;
      }
     
    }
     $data=array(
        'status'=>$no
      );
     $this->db->where('id_pengajuan',$id_pengajuan);
    $query=$this->db->update('pengajuan',$data);
     redirect('pengajuan/tampil_data3');
   }

	public function detail_data($id_pengajuan)
	{
		/*$this->simple_login->cek_login();*/		
		$query = $this->Model_Pengajuan->get_detail_pengajuan($id_pengajuan);
		$data['query'] = $query;
		$this->template->set('title', 'Detail Data Pengajuan');
		$this->template->load('admin_layout', 'contents', 'admin/Pengajuan/detail_pengajuan', $data );
	}

	public function detail_data2($id_pengajuan)
	{
		$this->simple_login->cek_login();	
		$query = $this->Model_Pengajuan->get_detail_pengajuan($id_pengajuan);
		$data['query'] = $query;
		$this->template->set('title', 'Detail Data Pengajuan');
		$this->template->load('default_user', 'contents', 'Karyawan/Pengajuan/detail_pengajuan', $data );
	}

  public function detail_data3($id_pengajuan)
  {
    $this->simple_login->cek_login();
    $query = $this->Model_Pengajuan->get_detail_pengajuan($id_pengajuan);
    $data['query'] = $query;
    $this->template->set('title', 'Detail Data Pengajuan');
    $this->template->load('default', 'contents', 'Pengajuan/detail_pengajuan', $data );
  }

  public function detail_data_after($id_detail)
  {
    $this->simple_login->cek_login();   
    $query = $this->Model_Pengajuan->get_edit_detail_pengajuan($id_detail);
    $data['query'] = $query;
    $this->template->set('title', 'Detail Data Pengajuan');
    $this->template->load('admin_layout', 'contents', 'admin/Pengajuan/detail_pengajuan', $data );
  }

  public function detail_data2_after($id_detail)
  {
    $this->simple_login->cek_login();   
    $query = $this->Model_Pengajuan->get_edit_detail_pengajuan($id_detail);
    $data['query'] = $query;
    $this->template->set('title', 'Detail Data Pengajuan');
    $this->template->load('default_user', 'contents', 'Karyawan/Pengajuan/detail_pengajuan', $data );
  }

  public function detail_data3_after($id_detail)
  {
    $this->simple_login->cek_login();   
    $query = $this->Model_Pengajuan->get_edit_detail_pengajuan($id_detail);
    $data['query'] = $query;
    $this->template->set('title', 'Detail Data Pengajuan');
    $this->template->load('default', 'contents', 'Pengajuan/detail_pengajuan', $data );
  }

  /*public function update_detail_status($id_pengajuan)
  {
    $this->form_validation->set_rules('id_pengajuan','ID Pengajuan','required');
    $this->form_validation->set_rules('id_user','Nama Pengaju','');
    $this->form_validation->set_rules('nama_barang','Nama Barang','required');
    $this->form_validation->set_rules('jml_barang','Jumlah','required');
    $this->form_validation->set_rules('tgl_pengajuan','Tanggal Pengajuan','required');
    $this->form_validation->set_rules('status','Status','');  

    if ($this->form_validation->run() == FALSE)
           {
               $status = $this->Model_Pengajuan->get_detail_pengajuan($id_pengajuan);
               $data['status'] = $status;
               $data['query'] = $this->Model_User->GetAllUser();
               $this->template->set('title', 'Detail Data Pengajuan');
               $this->template->load('default', 'contents', 'Pengajuan/update_status', $data );
           }
           else
           {
               $data = array(
                'id_pengajuan' => $this->input->post('id_pengajuan'),
                'id_user' => $this->input->post('id_user'),
                'nama_barang' => $this->input->post('nama_barang'),
                'jml_barang' => $this->input->post('jml_barang'),
                'tgl_pengajuan' => $this->input->post('tgl_pengajuan'),
                'status' => $this->input->post('status'),
              );
               $this->Model_Pengajuan->edit_data($id_pengajuan);
               $this->Model_BK->insert($data);
               redirect(base_url('index.php/Pengajuan/tampil_data3'));
           } 
    
  }
*/
  public function update($id_detail)
  {
    $this->simple_login->cek_login();
    $this->form_validation->set_rules('id_barang','Nama Barang');
    $this->form_validation->set_rules('jml_barang','Jumlah','required');

    if ($this->form_validation->run() == FALSE)
           {
               $data['query'] = $this->Model_Barang->GetAllBarang();
               $data['detail_pengajuan'] = $this->Model_Pengajuan->get_detail($id_detail)->row_array();
               $this->template->set('title', 'Update Data Pengajuan');
               $this->template->load('admin_layout', 'contents', 'Karyawan/Pengajuan/edit_pengajuan', $data );
           }
           else
           {
               $data = array(
                'id_barang' => $this->input->post('id_barang'),
                'jml_barang' => $this->input->post('jml_barang'),
              );
               $this->Model_Pengajuan->edit_data($id_detail);
               //redirect(base_url('index.php/Pengajuan/tampil_data2'));
               $this->detail_data2_after($id_detail);
           } 
    
  }

	public function update2($id_detail)
	{
		$this->simple_login->cek_login();
		$this->form_validation->set_rules('id_barang','Nama Barang');
		$this->form_validation->set_rules('jml_barang','Jumlah','required');

		if ($this->form_validation->run() == FALSE)
           {
               $data['query'] = $this->Model_Barang->GetAllBarang();
               $data['detail_pengajuan'] = $this->Model_Pengajuan->get_detail($id_detail)->row_array();
               $this->template->set('title', 'Update Data Pengajuan');
			         $this->template->load('default_user', 'contents', 'Karyawan/Pengajuan/edit_pengajuan', $data );
           }
           else
           {
               $data = array(
             		'id_barang' => $this->input->post('id_barang'),
             		'jml_barang' => $this->input->post('jml_barang'),
             	);
               $this->Model_Pengajuan->edit_data($id_detail);
               //redirect(base_url('index.php/Pengajuan/tampil_data2'));
               $this->detail_data2_after($id_detail);
           } 
		
	}

  public function update3($id_detail)
  {
    $this->simple_login->cek_login();
    $this->form_validation->set_rules('id_barang','Nama Barang','required');
    $this->form_validation->set_rules('jml_barang','Jumlah','required');


    if ($this->form_validation->run() == FALSE)
           {
               $data['query'] = $this->Model_Barang->GetAllBarang();
               $detail_pengajuan = $this->Model_Pengajuan->get_edit_detail_pengajuan($id_detail)->row_array();
               $data['detail_pengajuan'] = $detail_pengajuan;
               $this->template->set('title', 'Update Data Pengajuan');
               $this->template->load('default', 'contents', 'Pengajuan/edit_pengajuan', $data );
           }
           else
           { 
              $data = array(
                'id_barang' => $this->input->post('id_barang'),
                'jml_barang' => $this->input->post('jml_barang'),         
        );
            $this->Model_Pengajuan->edit_data($id_detail);
            //redirect(base_url('index.php/Pengajuan/detail_data3_after'));            
            $this->detail_data3_after($id_detail);
            } 
  }

    public function delete($id_pengajuan)
    {
		$this->simple_login->cek_login();
		$query = $this->Model_Pengajuan->hapus_data($id_pengajuan);
		$data['query'] = $query;
		$list = $this->Model_Pengajuan->GetJoinPengajuan();
		$data['list'] = $list;
        redirect(base_url('index.php/Pengajuan/tampil_data'));
	}

}
?>