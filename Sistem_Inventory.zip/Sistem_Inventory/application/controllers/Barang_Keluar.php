<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Barang_Keluar extends CI_Controller {
	
	public function update_detail_status($id_pengajuan)
  {
    /*$this->simple_login->cek_login();*/
    $this->form_validation->set_rules('id_brg_keluar', 'ID Barang Keluar', 'required');
	$this->form_validation->set_rules('id_pengajuan', 'Nama Pengaju', 'required');
	$this->form_validation->set_rules('id_barang', 'ID Barang', 'required');
	$this->form_validation->set_rules('jml_brg', 'Jumlah Barang', 'required');
	$this->form_validation->set_rules('tgl_pengambilan', 'Tanggal Keluar', 'required');
    $this->form_validation->set_rules('status','Status','');  

    if ($this->form_validation->run() == FALSE)
           {
               $status = $this->Model_Pengajuan->get_detail_pengajuan($id_pengajuan);
               $data['status'] = $status;
               $data['query'] = $this->Model_User->GetAllUser();
               $this->template->set('title', 'Detail Data Pengajuan');
               $this->template->load('default', 'contents', 'Pengajuan/update_status', $data );
           }
           else
           {
               $data = array(
                'id_pengajuan' => $this->input->post('id_pengajuan'),
                'id_user' => $this->input->post('id_user'),
                'nama_barang' => $this->input->post('nama_barang'),
                'jml_barang' => $this->input->post('jml_barang'),
                'tgl_pengajuan' => $this->input->post('tgl_pengajuan'),
                'status' => $this->input->post('status'),
              );
               $this->Model_Pengajuan->edit_data($id_pengajuan);
               redirect(base_url('index.php/Pengajuan/tampil_data3'));
           } 
    
  }

	public function tambah_data()
	{
		//$this->simple_login->cek_login();
		$this->form_validation->set_rules('id_brg_keluar', 'ID Barang Keluar', 'required');
		$this->form_validation->set_rules('id_pengajuan', 'Nama Pengaju', 'required');
		$this->form_validation->set_rules('id_barang', 'ID Barang', 'required');
		$this->form_validation->set_rules('jml_brg', 'Jumlah Barang', 'required');
		$this->form_validation->set_rules('tgl_pengambilan', 'Tanggal Keluar', 'required');
		

		if ($this->form_validation->run() == FALSE)
                {
						$data['id_auto'] = $this->Model_BK->create_id();
						$data['brg_keluar'] = $this->Model_BK->GetAllBK();					
                        $data['barang'] = $this->Model_Barang->GetAllBarang();
                        $data['pengajuan'] = $this->Model_Pengajuan->GetJoinPengajuan();
                        $this->template->set('title', 'Input Data Barang Keluar');
                        $this->template->load('admin_layout', 'contents' , 'admin/Transaksi/input_BK', $data);
                }
                else
                {
                $data= array(
    					'id_brg_keluar'=>$this->input->post('id_brg_keluar'),
    					'id_pengajuan'=>$this->input->post('id_pengajuan'),
    					'id_barang'=>$this->input->post('id_barang'),
    					'jml_brg'=>$this->input->post('jml_brg'),
    					'tgl_pengambilan'=>$this->input->post('tgl_pengambilan')    			
    				);

    			$this->Model_BK->insert($data);
    			redirect(base_url('index.php/Barang_Keluar/tampil_data'));
                       
                }
	}

	public function tampil_data()
	{
		$data['query'] = $this->Model_BK->GetJoinBK(); 				
		$this->template->set('title', 'Data Barang Keluar');
		$this->template->load('admin_layout', 'contents' , 'admin/Transaksi/tampil_BK', $data);
	}

	public function tampil_data2()
	{
		$data['query'] = $this->Model_BK->GetJoinBK(); 				
		$this->template->set('title', 'Data Barang Keluar');
		$this->template->load('default_user', 'contents' , 'Transaksi/tampil_BK', $data);
	}

	public function tampil_data3()
	{
		$data['query'] = $this->Model_BK->GetJoinBK();
		$this->template->set('title', 'Data Barang Keluar');
		$this->template->load('default', 'contents' , 'Transaksi/tampil_BK', $data);
	}

	public function update($id_brg_keluar)
	{
		
		$this->form_validation->set_rules('id_brg_keluar', 'ID Barang Keluar', 'required');
		$this->form_validation->set_rules('id_pengajuan', 'Nama Pengaju', 'required');
		$this->form_validation->set_rules('id_barang', 'ID Barang', 'required');
		$this->form_validation->set_rules('jml_brg', 'Jumlah Barang', 'required');
		$this->form_validation->set_rules('tgl_pengambilan', 'Tanggal Keluar', 'required');

		if ($this->form_validation->run() == FALSE)
                {
                        
                        $data['brg_keluar'] = $this->Model_BK->get_detail($id_brg_keluar)->result_array();
                        $data['barang'] = $this->Model_Barang->GetAllBarang();
                        $data['pengajuan'] = $this->Model_Pengajuan->GetAllPengajuan();
                        
                        $this->template->set('title', 'Update Data Paket');
						$this->template->load('admin_layout', 'contents' , 'admin/Transaksi/edit_BK', $data);
                }
                else
                {
                    $data= array(
	    					'id_brg_keluar'=>$this->input->post('id_brg_keluar'),
    						'id_pengajuan'=>$this->input->post('id_pengajuan'),
    						'id_barang'=>$this->input->post('id_barang'),
    						'jml_brg'=>$this->input->post('jml_brg'),
    						'tgl_pengambilan'=>$this->input->post('tgl_pengambilan')   
	    				);
                  	
	    			$query= $this->Model_BK->update($data, $id_brg_keluar);
	    			redirect(base_url('index.php/Barang_Keluar/tampil_data'));
                }
	}

	public function update2($id_brg_keluar)
	{
		
		$this->form_validation->set_rules('id_brg_keluar', 'ID Barang Keluar', 'required');
		$this->form_validation->set_rules('id_pengajuan', 'Nama Pengaju', 'required');
		$this->form_validation->set_rules('id_barang', 'ID Barang', 'required');
		$this->form_validation->set_rules('jml_brg', 'Jumlah Barang', 'required');
		$this->form_validation->set_rules('tgl_pengambilan', 'Tanggal Keluar', 'required');
		
		if ($this->form_validation->run() == FALSE)
                {
                        $data['id_auto'] = $this->Model_BK->create_id();
                        $data['brg_keluar'] = $this->Model_BK->get_detail($id_brg_keluar)->result_array();
                        $data['barang'] = $this->Model_Barang->GetAllBarang();
                        $data['pengajuan'] = $this->Model_Pengajuan->GetAllPengajuan();
                        $this->template->set('title', 'Update Data Paket');
						$this->template->load('default_user', 'contents' , 'Transaksi/edit_BK', $data);
                }
                else
                {
                    $data= array(
	    					'id_brg_keluar'=>$this->input->post('id_brg_keluar'),
    						'id_supplier'=>$this->input->post('id_supplier'),
    						'id_barang'=>$this->input->post('id_barang'),
    						'jml_brg'=>$this->input->post('jml_brg'),

    						'tgl_pengambilan'=>$this->input->post('tgl_pengambilan')   
	    				);
	    			$query= $this->Model_BK->update($data, $id_supplier);
	    			redirect(base_url('index.php/Barang_Keluar/tampil_data2'));
                }
	}		

	public function detail($id_brg_keluar)
	{
		$data['brg_keluar'] = $this->Model_BK->get_detail($id_brg_keluar);
		$this->template->set('title', 'Detail Data paket');
		$this->template->load('default', 'contents' , 'Transaksi/detail_BK', $data);
	}

	public function detail2($id_brg_keluar)
	{
		$data['brg_keluar'] = $this->Model_BK->get_detail($id_brg_keluar);
		$this->template->set('title', 'Detail Data paket');
		$this->template->load('default_user', 'contents' , 'Transaksi/detail_BK', $data);
	}

	public function delete($id_brg_keluar)
    {
    	$query = $this->Model_BK->hapus_data($id_brg_keluar);
		$data['query'] = $query;
		$list = $this->Model_BK->GetJoinBK();
		$data['list'] = $list;
    	redirect(base_url('index.php/Barang_Keluar/tampil_data'));
    }
}