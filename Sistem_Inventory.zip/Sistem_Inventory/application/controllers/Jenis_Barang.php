<?php
class Jenis_Barang extends CI_Controller {

	public function tambah_aksi(){
		/*$this->simple_login->cek_login();*/
		$this->form_validation->set_rules('id_jenis_barang','ID Jenis Barang','required');
		$this->form_validation->set_rules('nama_jenis_barang','Nama Jenis Barang','required');

		if ($this->form_validation->run() == FALSE)
           {
               $data['id_auto'] = $this->Model_Jenis->create_id();
               $data['query'] = $this->Model_Jenis->GetAllJenis();
               $this->template->set('title', 'Input Data Jenis Barang');
               $this->template->load('admin_layout', 'contents', 'Jenis/input_jenis', $data );
           }
           else
           { 
				$data = array(
           			'id_jenis_barang' => $this->input->post('id_jenis_barang'),
             		'nama_jenis_barang' => $this->input->post('nama_jenis_barang'),
				);
			$this->Model_Jenis->input_data($data);
			redirect(base_url('index.php/Jenis_Barang/tampil_data'));
            } 
	}

	public function tampil_data()
	{
		//$this->simple_login->cek_login();
        $query = $this->Model_Jenis->GetAllJenis();
        $data['query'] = $query;
        $this->template->set('title', 'Data Jenis Barang');
		$this->template->load('admin_layout', 'contents', 'Jenis/tampil_jenis', $data );
	}

	public function update($id_jenis_barang)
	{
		/*$this->simple_login->cek_login();*/
		$this->form_validation->set_rules('id_jenis_barang','ID Jenis Barang','required');
		$this->form_validation->set_rules('nama_jenis_barang','Nama Jenis Barang','required');


		if ($this->form_validation->run() == FALSE)
           {
               $data['query'] = $this->Model_Jenis->GetAllJenis();
               $data['jenis_barang'] = $this->Model_Jenis->get_detail($id_jenis_barang)->row_array();
               $this->template->set('title', 'Update Data Jenis Barang');
			   $this->template->load('admin_layout', 'contents', 'Jenis/edit_jenis', $data );
           }
           else
           { 
				$data = array(
					'id_jenis_barang' => $this->input->post('id_jenis_barang'),
             		'nama_jenis_barang' => $this->input->post('nama_jenis_barang'),					
				);
            $this->Model_Jenis->edit_data($id_jenis_barang);
			redirect(base_url('index.php/Jenis_Barang/tampil_data'));            
            } 
	}

	public function delete($id_jenis_barang)
    {
		/*$this->simple_login->cek_login();*/
		$query = $this->Model_Jenis->hapus_data($id_jenis_barang);
		$data['query'] = $query;
        redirect(base_url('index.php/Jenis_Barang/tampil_data'));
	}	

}
?>
