<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
	public $data =array();

	public function tambah_data(){
		/*$this->simple_login->cek_login();*/
		$this->form_validation->set_rules('id_user','ID User','required');
		/*$this->form_validation->set_rules('id_uk','Unit Kerja','');*/
		$this->form_validation->set_rules('username','Username','required');
		$this->form_validation->set_rules('password','Password','required');
		$this->form_validation->set_rules('nama','Nama','required');
		$this->form_validation->set_rules('nip','NIP','required');
		$this->form_validation->set_rules('jabatan','Jabatan','required');
		$this->form_validation->set_rules('peran','Peran','required');		

		if ($this->form_validation->run() == FALSE)
           {
               $data['id_auto'] = $this->Model_User->create_id();
               $data['user'] = $this->Model_User->GetAllUser();
               $data['query'] = $this->Model_Uker->GetAllUker();
               $this->template->set('title', 'Form Input Data Karyawan Baru');
               $this->template->load('admin_layout', 'contents', 'User/input_user', $data );
           }
           else
           {
           		$data = array(
           		 	'id_user' => $this->input->post('id_user'),
           		 	'id_uk' => $this->input->post('id_uk'),
              		'username' => $this->input->post('username'),
              		'password' => $this->input->post('password'),
              		'nama' => $this->input->post('nama'),
              		'nip' => $this->input->post('nip'),
              		'jabatan' => $this->input->post('jabatan'),
              		'peran' => $this->input->post('peran')
              	);

                $this->Model_User->insert($data);
                redirect(base_url('index.php/User/tampil_data'));
               /* print_r($this->input->post());*/
           } 
	}

	public function tampil_data()
	{
		//$data['query'] = $this->Model_User->GetAllUser();
		$query = $this->Model_User->GetJoinUser();
        $data['query'] = $query;
		$this->template->set('title', 'Dashboard');
		$this->template->load('admin', 'contents' , 'User/tampil_user', $data );
	}

	public function detail_data($id_user)
	{
		/*$this->simple_login->cek_login();*/		
		$query = $this->Model_User->get_detail($id_user);
		$data['query'] = $query;
        $data['user'] = $this->Model_User->GetJoinUser();
		$this->template->set('title', 'Detail Data User');
		$this->template->load('admin_layout', 'contents', 'User/detail_user', $data );
	}

	public function update($id_user)
	{
		/*$this->simple_login->cek_login();*/
		$this->form_validation->set_rules('id_user','ID User','required');
		/*$this->form_validation->set_rules('id_uk','Unit Kerja','');*/
		$this->form_validation->set_rules('username','Username','required');
		$this->form_validation->set_rules('password','Password','required');
		$this->form_validation->set_rules('nama','Nama','required');
		$this->form_validation->set_rules('nip','NIP','required');
		$this->form_validation->set_rules('jabatan','Jabatan','');
		/*$this->form_validation->set_rules('peran','Peran','required');*/

		if ($this->form_validation->run() == FALSE)
           {
               $data['id_auto'] = $this->Model_Barang->create_id();
               $data['user'] = $this->Model_User->get_detail($id_user)->result_array();
               $data['query'] = $this->Model_Uker->GetAllUker();
               $this->template->set('title', 'Update Data User');
			   $this->template->load('admin_layout', 'contents', 'User/edit_user', $data );
           }
           else
           {
               $data = array(
           			'id_user' => $this->input->post('id_user'),
           			'id_uk' => $this->input->post('id_uk'),
             		'username' => $this->input->post('username'),
             		'password' => $this->input->post('password'),
             		'nama' => $this->input->post('nama'),
             		'nip' => $this->input->post('nip'),
             		'jabatan' => $this->input->post('jabatan'),
             		'peran' => $this->input->post('peran')
             	);
               $this->Model_User->edit_data($id_user);
               redirect(base_url('index.php/User/tampil_data'));
           } 	
	}

    public function delete($id_user)
    {
		/*$this->simple_login->cek_login();*/
		$query = $this->Model_User->hapus_data($id_user);
		$data['query'] = $query;
		$list = $this->Model_User->GetJoinUser();
		$data['list'] = $list;
        redirect(base_url('index.php/User/tampil_data'));
	}
	
	public function logout() {
		$this->simple_login->logout();	
	}
}
?>