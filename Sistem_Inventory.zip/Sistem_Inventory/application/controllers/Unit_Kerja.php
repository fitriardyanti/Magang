<?php
class Unit_Kerja extends CI_Controller {

	public function tambah_aksi(){
		/*$this->simple_login->cek_login();*/
		$this->form_validation->set_rules('id_uk','ID Jenis Barang','required');
		$this->form_validation->set_rules('nama_uk','Nama Jenis Barang','required');

		if ($this->form_validation->run() == FALSE)
           {
               $data['id_auto'] = $this->Model_Uker->create_id();
               $data['query'] = $this->Model_Uker->GetAllUker();
               $this->template->set('title', 'Input Data Jenis Barang');
               $this->template->load('admin_layout', 'contents', 'Uker/input_uker', $data );
           }
           else
           { 
				$data = array(
           			'id_uk' => $this->input->post('id_uk'),
             		'nama_uk' => $this->input->post('nama_uk'),
				);
			$this->Model_Uker->input_data($data);
			redirect(base_url('index.php/Unit_Kerja/tampil_data'));
            } 
	}

	public function tampil_data()
	{
		//$this->simple_login->cek_login();
        $query = $this->Model_Uker->GetAllUker();
        $data['query'] = $query;
        $this->template->set('title', 'Data Unit Kerja');
		$this->template->load('admin_layout', 'contents', 'Uker/tampil_uker', $data );
	}

	public function update($id_uk)
	{
		/*$this->simple_login->cek_login();*/
		$this->form_validation->set_rules('id_uk','ID Jenis Barang','required');
		$this->form_validation->set_rules('nama_uk','Nama Jenis Barang','required');


		if ($this->form_validation->run() == FALSE)
           {
               $data['query'] = $this->Model_Uker->GetAllUker();
               $data['unit_kerja'] = $this->Model_Uker->get_detail($id_uk)->row_array();
               $this->template->set('title', 'Update Data Unit Kerja');
			   $this->template->load('admin_layout', 'contents', 'Uker/edit_uker', $data );
           }
           else
           { 
				$data = array(
					'id_uk' => $this->input->post('id_uk'),
             		'nama_uk' => $this->input->post('nama_uk'),					
				);
            $this->Model_Uker->edit_data($id_uk);
			redirect(base_url('index.php/Unit_Kerja/tampil_data'));            
            } 
	}

	public function delete($id_uk)
    {
		/*$this->simple_login->cek_login();*/
		$query = $this->Model_Uker->hapus_data($id_uk);
		$data['query'] = $query;
        redirect(base_url('index.php/Unit_Kerja/tampil_data'));
	}	

}
?>
