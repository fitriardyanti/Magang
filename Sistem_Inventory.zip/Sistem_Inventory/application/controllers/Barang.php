<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Barang extends CI_Controller {

	public function tambah_data()
	{
		$this->simple_login->cek_login();		
		$this->form_validation->set_rules('id_barang','Tanggal Lahir','required');
		$this->form_validation->set_rules('nama_barang','Asal Sekolah','required');
		$this->form_validation->set_rules('id_jenis_barang','id_jenis_barang','required');
		$this->form_validation->set_rules('stock','stock','required');
		$this->form_validation->set_rules('satuan','satuan','required');

		if ($this->form_validation->run() == FALSE)
           {
               $data['id_auto'] = $this->Model_Barang->create_id();
               $data['barang'] = $this->Model_Barang->GetAllBarang();
               $data['query'] = $this->Model_Jenis->GetAllJenis();
               $this->template->set('title', 'Form Input data Barang');
               $this->template->load('admin_layout', 'contents', 'admin/Barang/input_barang', $data );
           }
           else
           {
           		$data = array(
           			'id_barang' => $this->input->post('id_barang'),
             		'nama_barang' => $this->input->post('nama_barang'),
             		'id_jenis_barang' => $this->input->post('id_jenis_barang'),
             		'stock' => $this->input->post('stock'),
             		'satuan' => $this->input->post('satuan')
            );
                $this->Model_Barang->insert($data);
                redirect(base_url('index.php/Barang/tampil_data'));
           } 
	}

	public function tampil_data()
	{
		$data['list'] = $this->Model_Barang->GetAllBarang();
        $list = $this->Model_Barang->GetJoinBarang();
        $data['list'] = $list;
        $this->template->set('title', 'Data Barang');
		$this->template->load('admin_layout', 'contents', 'admin/Barang/tampil_barang', $data );
	}

	public function tampil_data2()
	{
		$data['list'] = $this->Model_Barang->GetAllBarang();
        $list = $this->Model_Barang->GetJoinBarang();
        $data['list'] = $list;
        $this->template->set('title', 'Data Barang');
		$this->template->load('default_user', 'contents', 'Barang/tampil_barang', $data );
	}

	public function tampil_data3()
	{
		$data['list'] = $this->Model_Barang->GetAllBarang();
        $list = $this->Model_Barang->GetJoinBarang();
        $data['list'] = $list;
        $this->template->set('title', 'Data Barang');
		$this->template->load('default', 'contents', 'Barang/tampil_barang', $data );
	}

	public function detail_data($id_barang)
	{
		/*$this->simple_login->cek_login();*/		
		$query = $this->Model_Barang->get_detail($id_barang);
		$data['query'] = $query;
		$this->template->set('title', 'Detail Barang');
		$this->template->load('admin_layout', 'contents', 'admin/Barang/detail_barang', $data );
	}

	public function detail_data2($id_barang)
	{
		/*$this->simple_login->cek_login();*/		
		$query = $this->Model_Barang->get_detail($id_barang);
		$data['query'] = $query;
		$this->template->set('title', 'Detail Barang');
		$this->template->load('default_user', 'contents', 'Barang/detail_barang', $data );
	}

	public function detail_data3($id_barang)
	{
		/*$this->simple_login->cek_login();*/		
		$query = $this->Model_Barang->get_detail($id_barang);
		$data['query'] = $query;
		$this->template->set('title', 'Detail Barang');
		$this->template->load('default', 'contents', 'Barang/detail_barang', $data );
	}

	public function update($id_barang)
	{
		/*$this->simple_login->cek_login();*/
		$this->form_validation->set_rules('id_barang','ID Barang','required');
		$this->form_validation->set_rules('nama_barang','Nama Barang','required');
		$this->form_validation->set_rules('id_jenis_barang','Jenis Barang','required');
		$this->form_validation->set_rules('stock','Stock Barang','required');
		$this->form_validation->set_rules('satuan','satuan','required');
		
		if ($this->form_validation->run() == FALSE)
           {
               $data['barang'] = $this->Model_Barang->get_detail($id_barang)->result_array();
               $data['query'] = $this->Model_Jenis->GetAllJenis();
               $this->template->set('title', 'Update Data Barang');
			   $this->template->load('admin_layout', 'contents', 'admin/Barang/edit_barang', $data );
           }
           else
           {
           		$data = array(
                    'id_barang' => $this->input->post('id_barang'),
                    'nama_barang' => $this->input->post('nama_barang'),
                    'id_jenis_barang' => $this->input->post('id_jenis_barang'),
                    'stock' => $this->input->post('stock'),
                    'satuan' => $this->input->post('satuan'),
            	);

               $this->Model_Barang->edit_data($id_barang);
               redirect(base_url('index.php/Barang/tampil_data'));
           } 
		
	}
	
    public function delete($id_barang)
    {
		/*$this->simple_login->cek_login();*/
		$query = $this->Model_Barang->hapus_data($id_barang);
		$data['query'] = $query;
		$list = $this->Model_Barang->GetJoinBarang();
		$data['list'] = $list;
        redirect(base_url('index.php/Barang/tampil_data'));
	}
	
}
?>
